/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;

import java.util.LinkedList;
import java.util.Random;
import static project3.Node.*;

/**
 *
 * @author Dylan Lowman
 */
public class DeadList {
      static protected DeadNode start = null;
      static protected DeadNode end = null;
      static protected DeadNode currentPlayer = null;
      static private DeadNode leftPlayer = null;
      static private DeadNode rightPlayer = null;
      static private int boneyardPile[] = {0,0,1,1,1,1,1,1,2,2,2};
      static Random rand = new Random();
      static int zombieCardNumber,zombieCardValue;
      static boolean zombieOutbreakStart = false;
 
      public static void insert(Character player, String name,String lifeStatus,String role,int valueZombieCard)
      {
       DeadNode DeadNode = new DeadNode(); //creates a new node
       DeadNode.player = player;//specifies that these paremters are linked to the variables inside the node
       DeadNode.name = name;
       DeadNode.lifeStatus = lifeStatus;
       DeadNode.role = role;
       DeadNode.valueZombieCard = valueZombieCard;
       DeadNode.prev = null;
       DeadNode.next = null;
       
       if(start == null){
           start = DeadNode;
           DeadNode.next = start;
           DeadNode.prev = end;
       }
       else{
           currentPlayer = start;
               
           while(currentPlayer.next != start){
               currentPlayer = currentPlayer.next;
           }
           DeadNode.prev = currentPlayer;
           currentPlayer.next = DeadNode;
           end = DeadNode;
           DeadNode.next = start;
           start.prev = end;
           
       }
     }
     public static void show()
     {
       currentPlayer = start;
       
       if(start != null){
           System.out.println("*************************************************************************************");
           System.out.println("GraveYard");
          do{
               if(currentPlayer.name.equals(Project3.chosenCharacter)){
                      System.out.println("YOUR PLAYER:" +  currentPlayer.player + " Role:" + currentPlayer.role + "  " + currentPlayer.lifeStatus );
               }
              else{
                      System.out.println("PLAYER:" +  currentPlayer.player + " Role:" + currentPlayer.role + "  " + currentPlayer.lifeStatus );
               }
               currentPlayer = currentPlayer.next; 
           
            }while(currentPlayer != start);
       }
       System.out.println("*************************************************************************************");
    }
     public static void bringZombiesInGame(){
        int playerCount = 0;
        CharacterLinkedList.currentNode = CharacterLinkedList.start;
       //check how many players are left in the game and make the renegade the zombie master
        if( CharacterLinkedList.start != null){
        
          do{
               playerCount++;
               CharacterLinkedList.currentNode = CharacterLinkedList.currentNode.next;
            }while(CharacterLinkedList.currentNode != CharacterLinkedList.start);
        }
        //make the renegade the zombie master 
          if( CharacterLinkedList.start != null){
        
          do{
               CharacterLinkedList.currentNode = CharacterLinkedList.currentNode.next;
               if(CharacterLinkedList.currentNode.role.equals("RENEGADE")){
                  System.out.println(CharacterLinkedList.currentNode.player + " has changed to the ZOMBIE MASTER");
                  CharacterLinkedList.currentNode.revealedRole = true;
                  CharacterLinkedList.currentNode.role = "ZOMBIEMASTER";
               }
            }while(CharacterLinkedList.currentNode != CharacterLinkedList.start);
        }
        //insert the zombies into the game and remove them from the graveyard
         if(start == null){
              System.out.println("zombie outbreak was activated but no players in the graveyard");
         }
         else{
              currentPlayer = end;
          do{
              System.out.println(currentPlayer.player + " has been brought back from the grave!");
              CharacterLinkedList.insert(currentPlayer.player, currentPlayer.name,playerCount,"ZOMBIE",0,true, playerCount,"UnDead",new LinkedList());
              rightPlayer = currentPlayer;
              currentPlayer = currentPlayer.prev;
              rightPlayer.next = null;
              rightPlayer.prev = null;
            }while(currentPlayer != end);
              start = null;
              end = null;
        }
     }
     public static boolean checkZombieOutbreak(){
        boolean zombieCancelCardOccurs = false;
        int totalZombieHands = 0;
        currentPlayer = start;
        int count = 0;
      
       if(start != null){
          do{  
              zombieCardNumber = rand.nextInt(11);
              zombieCardValue = boneyardPile[zombieCardNumber];
              if(zombieCardValue == 0){
                  zombieCancelCardOccurs = true;
              }
              totalZombieHands += zombieCardValue;
              currentPlayer = currentPlayer.next; 
              count++;
              if(zombieCardValue == 0){
                  System.out.println(currentPlayer.player + " zombieCard: cancel card" );
              }
              else{
                   System.out.println(currentPlayer.player + " zombieCard: " + zombieCardValue);
              }
            }while(currentPlayer != start);
       }
       if(totalZombieHands > winConditions.playerCount && zombieCancelCardOccurs == false){
            zombieOutbreakStart = true;
             System.out.println( " zombieCardTotal: " + totalZombieHands);
             System.out.println( " ZOMBIE OUTBREAK ACTIVATED! " );
              return true;
       }
       else{
           return false;
       }
    }
    
}
    
