/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;

/*
 * a window that is seperate from the main window, doesnt mix input with each other 
   and wont let anything happen until it is exited
 */

/**
 *
 * @author Dylan Lowman
 */
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AlertBox {
    public static void display(String title, String message){
        Stage stage = new Stage();
        
        //block input events with other windows till this one is taken care of
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(title);
        stage.setMinWidth(250);
        
        Label label= new Label();
        label.setText(message);
        
        Button closeButton = new Button("Close the window");
        closeButton.setOnAction(e -> stage.close());
        
        VBox layout = new VBox(10);
        layout.getChildren().addAll(label,closeButton);
        layout.setAlignment(Pos.CENTER);
        
        //Scene
        Scene scene = new Scene(layout);
        stage.setScene(scene); //adds the scene to the window
        stage.showAndWait(); //displays the window and until it returns the main function must be closed 
    }
    
}