/*
 * character class that contains the information to create a character object
 */
package project3;

/**
 *
 * @author Dylan Lowman
 */
public class Character {
    private Characters name;
    
    public Character(Characters name){
        this.name = name;
    }
    
    enum Characters{
        BLACK_JACK(8),JESSE_JONES(9),JOURDONNAIS(7),LUCKY_DUKE(8),PAUL_REGRET(9),SUZY_LAFAYETTE(8),WILLY_THE_KID(8),
        GREG_DIGGER(7),BELLE_STAR(8),JOSE_DELGADO(7),TEQUILA_JOE(7);
        
        private final int lifepoints;
        
        private Characters(int lifepoints){
            this.lifepoints = lifepoints;
        }
        public int getLifes(){
            
            return lifepoints;
        }
        private static Characters character[] = Characters.values();
        public static Characters getCharacter(int characterIndex){
            
            return Characters.character[characterIndex];
        }
    }
    public String toString(){
        
        return " "  + name;
        
    }
    
}

