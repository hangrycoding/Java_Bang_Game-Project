
package project3;

import java.util.LinkedList;

/**
 *
 * @author Dylan Lowman
 */
public class Node {
    Character player;//enum of the character
    String name;
    int lifes;
    boolean revealedRole;
    String role;
    int arrows;
    int maxLifes; //controls how much life the charcter cannot exceed
    String lifeStatus;
    LinkedList<String> duelWoundLink = new LinkedList();
    Node prev;//pointer for the prev node
    Node next;//pointer for the next node
}
