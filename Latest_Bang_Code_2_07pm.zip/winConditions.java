package project3;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 import static project3.CharacterLinkedList.*;
/**
 *
 * @author Jun Juwang
 */
public class winConditions {
    static String winner;
    static boolean onePlayer;
    static int playerCount;
    static int count,endWinnerCount;
    
    public static boolean checkWinConditions(){
       boolean gameOver = false;
        playerCount = 0;
        //sheriff,renegade,outlaw,deputy,zombie
       int roleTypeCount[] = {0,0,0,0,0};
       //zombie,zombieMaster,survivor
       int unDeadRoleTypeCount[] = {0,0,0};
       
       if(start == null)
           gameOver = true;
       else if(Project3.mainStartZombieOutbreak == true){ //zombie outbreak rules
               currentNode = start;
                do{
                     playerCount++;
                     if(currentNode.role.equals("ZOMBIE")){
                        unDeadRoleTypeCount[0]++;
                     }
                     else if(currentNode.role.equals("ZOMBIEMASTER")){
                         unDeadRoleTypeCount[1]++;
                     }
                     else{
                         unDeadRoleTypeCount[2]++;
                     }
                     currentNode = currentNode.next;
                  }while(currentNode != start);
                     /*System.out.println( "zombie" + unDeadRoleTypeCount[0]);
                     System.out.println(  "zombieMaster" + unDeadRoleTypeCount[1]);
                     System.out.println(  "survivor" + unDeadRoleTypeCount[2]);*/
                if(unDeadRoleTypeCount[0] == 0 && unDeadRoleTypeCount[1] == 0 && unDeadRoleTypeCount[2] != 0){
                    if(count == 0)
                    System.out.println("THE SURVIVORS WIN!");
                    winner = "SURVIVORS";
                    scan.nextLine();
                    gameOver = true;
                    count++;
                }
                else if( unDeadRoleTypeCount[2] == 0){
                    if(count == 0)
                    System.out.println("THE ZOMBIES WIN!");
                    winner = "ZOMBIES";
                    scan.nextLine();
                    gameOver = true;
                    count++;
                }
           
          
       }
       else{     
                currentNode = start;
                do{
                     playerCount++;
                     if(currentNode.role.equals("SHERIFF"))
                         roleTypeCount[0]++;
                     else if(currentNode.role.equals("RENEGADE"))
                         roleTypeCount[1]++;
                     else if(currentNode.role.equals("OUTLAW"))
                         roleTypeCount[2]++;
                     else if(currentNode.role.equals("DEPUTY"))
                         roleTypeCount[3]++;
                     
                     currentNode = currentNode.next;
               
                  }while(currentNode != start);
                if(roleTypeCount[0] == 0){
                    if(count == 0)
                    System.out.println("THE SHERIFF IS DEAD!");
                    scan.nextLine();
                    gameOver = true;
                    if(roleTypeCount[1] == 1 && roleTypeCount[2] == 0 && roleTypeCount[3] == 0 ) //if renegade is still alive then renegades win
                        winner = "RENEGADE";
                    else 
                        winner = "OUTLAWS";
                    count++;
                }
                else if(roleTypeCount[1] == 0 && roleTypeCount[2] == 0){
                    if(count == 0)
                    System.out.println("All OUTLAWS and RENEGADES are dead, SHERIFF AND DEPUTIES WIN");
                    scan.nextLine();
                    winner = "SHERIFF & DEPUTY";
                     gameOver = true;
                     count++;
                }
                else if(roleTypeCount[0] == 0 && roleTypeCount[1] == 1 && roleTypeCount[2] == 0 && roleTypeCount[3] == 1){
                    if(count == 0)
                    System.out.println("OUTLAWS WIN their objective was achieved");
                    winner = "OUTLAWS";
                     gameOver = true;
                     count++;
                }
                if(playerCount == 1){
                    gameOver = true;
                }
                if(playerCount == 0){
                    gameOver = true;
                    System.out.println("OUTLAWS WIN since nobody achieved there objective");
                    winner = "OUTLAWS";
                }
       }
       if(gameOver == true){
           if(endWinnerCount == 0)
           System.out.println("Winner: " + winner);
           endWinnerCount++;
       }
       return gameOver;
   }
    
}
