/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;
import java.util.Stack;
import java.util.Random;

/**
 *
 * @author Jacob Hewgley
 */
public class Arrows {
    static boolean indianArrowAttack;
    static Stack<Integer> arrowsStack = new Stack<Integer>();
    static Stack<Integer> chiefArrowStack = new Stack<Integer>();
    static Random rand = new Random();
    /*****************************************************
     * base game arrow methods
     *****************************************************/

    int arrowAmountLeft; 
    public static void arrowPush(Stack<Integer> stack,int arrowNumber) 
    { 
        for(int i = 0; i < arrowNumber; i++) 
        { 
            stack.push(i); 
        } 
        System.out.println("  " + arrowNumber + " arrows onto the stack");
        return;
    } 
    // Popping element from the top of the stack 
    public static void stackPop(Stack<Integer> stack) 
    { 
           if(stack.peek() != 0) {
                Integer arrow = (Integer) stack.pop();
                int arrowAmountLeft = arrow - 1;
                System.out.println("  -1 " + "arrow from the stack " + arrowAmountLeft + " arrows left on the stack");
               
           }
    } 
    public static void indiansAttack(Stack<Integer> stack,Node AttackArrow){
        //checks if the stack is empty
        if(stack.peek() == 0)
        {
            System.out.println("THE ARROW STACK IS NOW EMPTY!");
            System.out.println("THE INDIANS ARE ATTACKING!");
            Project3.ArrowAttack = CharacterLinkedList.start;
            do{
                //JOURDONNAIS SPECIAL ABILITY IMPLEMENTED
                 if(!(Project3.ArrowAttack.name.equals("JOURDONNAIS"))){
                      Project3.ArrowAttack.lifes -= Project3.ArrowAttack.arrows;
                      System.out.println(Project3.ArrowAttack.player + " has lost " + Project3.ArrowAttack.arrows + " life" + " has " + Project3.ArrowAttack.lifes + " left");
                     //sets all the characters arrows to zero
                      Project3.ArrowAttack.arrows = 0;
                 }
                 else{
                     if(Project3.ArrowAttack.arrows > 1){
                         System.out.println("" + Project3.ArrowAttack.player + "'S SPECIAL ABILITY ACTIVATED: he only takes 1 damage to indians and not " + Project3.ArrowAttack.arrows);    
                         Project3.ArrowAttack.lifes -= 1;
                         System.out.println(Project3.ArrowAttack.player + " has lost " + "1" + " life" + " has " + Project3.ArrowAttack.lifes + " left");
                         //sets all the characters arrows to zero
                         Project3.ArrowAttack.arrows = 0;
                     }
                     else{
                         Project3.ArrowAttack.lifes -= Project3.ArrowAttack.arrows;
                         System.out.println(Project3.ArrowAttack.player + " has lost " + Project3.ArrowAttack.arrows + " life" + " has " + Project3.ArrowAttack.lifes + " left");
                         //sets all the characters arrows to zero
                         Project3.ArrowAttack.arrows = 0;
                         
                     }
                 }
                  Project3.ArrowAttack = Project3.ArrowAttack.next;
                  
            }while(Project3.ArrowAttack != CharacterLinkedList.start);
           //pushes all the arrows onto the stack 
            for(int i = 0; i < 9; i++) 
             { 
                 stack.push(i); 
             } 
             System.out.println(" 9 " + "arrows back onto the stack");
        }
     
      return;
    }
    /**********************************************************
     * old saloon expansion arrow methods
     **********************************************************/
    public static void oldSaloonArrowPush(Stack<Integer> stack,int arrowNumber) 
    { 
        for(int i = 0; i < arrowNumber; i++) 
        {
            stack.push(i); 
        } 
        System.out.println(arrowNumber + " arrows onto the stack");
        return;
    } 
    // Popping element from the top of the stack 
    public static void oldSaloonStackPop(Stack<Integer> stack) 
    { 
           if(stack.size() != 1){
                Integer arrow = (Integer) stack.pop();
                int arrowAmountLeft = arrow - 1;
                System.out.println("  -1 " + "arrow from the stack " + arrowAmountLeft + " arrows left on the stack");
               
           }
    } 
    public static void chiefIndiansAttack(Stack<Integer> stack,Node AttackArrow){
        //checks if the stack is empty
        if(stack.peek() != 0) 
        {
            
           System.out.println("THE INDIANS ARE ATTACKING!");
           Project3.ArrowAttack = CharacterLinkedList.start;
           while(Project3.ArrowAttack.next != CharacterLinkedList.start)
           {
                 Project3.ArrowAttack = Project3.ArrowAttack.next;
                 Project3.ArrowAttack.lifes -= Project3.ArrowAttack.arrows;
                 System.out.println(Project3.ArrowAttack.player + " has lost " + Project3.ArrowAttack.arrows + " life" + " has " + Project3.ArrowAttack.lifes + " left");
                 //sets all the characters arrows to zero
                 Project3.ArrowAttack.arrows = 0;
           }
           //pushes all the arrows onto the stack 
            int ChiefArrow = rand.nextInt(10); // Randomize ChiefArrow in stack
            for(int i = 0; i < 9; i++) 
             { 
                 
             }
        }
     
      return;
    }
    
 
    
}
