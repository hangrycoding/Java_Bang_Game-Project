/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;
import  java.util.Random;
import  project3.Project3.*;
import  project3.CharacterLinkedList.*;
import  project3.Arrows.*;
import  java.util.Scanner;
import static project3.Project3.*;

/**
 *
 * @author Dylan Lowman and Nick Adams
 */
public class Dice {
     //handles the final dice that have been rolled.
     static Scanner scan = new Scanner(System.in);
     static Random rand = new Random();
     static int diceFaceCount[] = {0,0,0,0,0,0};
     static int cowardDiceCount[] = {0,0,0,0,0,0};
     static int loudMouthDiceCount[] = {0,0,0,0,0,0};
     static int duelDiceCount[] = {0,0,0,0,0,0};
     //handles the amount of rerolls that the play has done per the dice.
     static int diceFaceCountReroll[] = {0,0,0,0,0,0};
     static int rollCount = 0, dynamiteCounter,diceCalculationsCount = 0,doubleSymbol = 0,rerollPhaseAmount = 0,numberOfCalculation = 0;
     static int randomNumber3;
     static int questionCount = 0,brokenArrowCount = 0, bulletCount = 0,duelCount = 0;
     static int randDirection = rand.nextInt(2);
     static String userInput; 
     static boolean beerLimitExceeded,playerHasArrows,brokenArrowAlreadyCalculated,bulletAlreadyCalculated,duelAlreadyCalculated;
     static boolean rerollTerminated = false,duelAlreadyAdded;
    
     enum DiceFace{
            INDIANARROW("INDIANARROW"),DYNAMITE("DYNAMITE"),BULLSEYE1("BULLSEYE1"),
            BULLSEYE2("BULLSEYE2"),BEER("BEER"),GATLINGGUN("GATLINGGUN");
            
            final private String diceFace_toString;
            
            private DiceFace(String diceFace_toString){
                this.diceFace_toString = diceFace_toString;
            }
              private static final DiceFace dicefaces[] = DiceFace.values();
            public static DiceFace getDiceFace(int characterIndex){
                return DiceFace.dicefaces[characterIndex];
            }
            public String getdiceFace_toString(){
                    
                return diceFace_toString;
            }
            
     }
     enum CowardDiceFace{
            INDIANARROW("INDIANARROW"),BROKENARROW("BROKENARROW"),DYNAMITE("DYNAMITE"),BULLSEYE1("BULLSEYE1")
            ,BEER("BEER"),DOUBLEBEER("DOUBLEBEER");
            
            final private String CowardDiceFace_toString;
            
            private CowardDiceFace(String expansionDiceFace_toString){
                this.CowardDiceFace_toString = expansionDiceFace_toString;
            }
              private static final CowardDiceFace CowardDiceFaces[] = CowardDiceFace.values();
            public static CowardDiceFace getDiceFace(int characterIndex){
                return CowardDiceFace.CowardDiceFaces[characterIndex];
            }
            public String getdiceFace_toString(){
                    
                return CowardDiceFace_toString;
            }
            
     }
     enum LoudMouthDiceFace{
            INDIANARROW("INDIANARROW"),BULLET("BULLET"),DYNAMITE("DYNAMITE"),DOUBLEBULLSEYE1("DOUBLEBULLSEYE1")
            ,DOUBLEBULLSEYE2("DOUBLEBULLSEYE2"),DOUBLEGATLINGGUN("DOUBLEBEER");
            
            final private String LoudMouthDiceFace_toString;
            
            private LoudMouthDiceFace(String LoudMouthDiceFace_toString){
                this.LoudMouthDiceFace_toString = LoudMouthDiceFace_toString;
            }
              private static final LoudMouthDiceFace LoudMouthDiceFaces[] = LoudMouthDiceFace.values();
            public static  LoudMouthDiceFace getLoudMouthDiceFace(int characterIndex){
                return  LoudMouthDiceFace.LoudMouthDiceFaces[characterIndex];
            }
            public String getdiceFace_toString(){
                    
                return LoudMouthDiceFace_toString;
            }
            
     }
      enum DuelDiceFace{
            INDIANARROW("INDIANARROW"),DYNAMITE("DYNAMITE"),WHISKEYBOTTLE("WHISKEYBOTTLE"),BEER("BEER"),
            GATLINGGUN("GATLINGGUN"),DUEL("DUEL");
            
            final private String DuelDiceFace_toString;
            
            private DuelDiceFace(String DuelDiceFace_toString){
                this.DuelDiceFace_toString = DuelDiceFace_toString;
            }
              private static DuelDiceFace DuelDiceFaces[] = DuelDiceFace.values();
            public static DuelDiceFace getDiceFace(int characterIndex){
                return DuelDiceFace.DuelDiceFaces[characterIndex];
            }
            public String getdiceFace_toString(){
                    
                return DuelDiceFace_toString;
            }
            
     }
       
      //method for the reroll function.
      public static void reroll(int numberOfRoll){
          Random rand = new Random();
          int index = 0;
          dynamiteCounter = 0;
          rerollTerminated = false;
          switch(Project3.userChoiceOfReroll){
              case 1:  index = 0;
                       diceFaceCountReroll[0]++;
                        break;
              case 2:  index = 1;
                       diceFaceCountReroll[1]++;
                        break;
              case 3:  index = 2;
                       diceFaceCountReroll[2]++;
                        break;
              case 4:  index = 3;
                       diceFaceCountReroll[3]++;
                        break;
              case 5:  index = 4;
                       diceFaceCountReroll[4]++;
                        break;
              case 6:  index = 5;
                       diceFaceCountReroll[5]++;
                       break;
              case 7:  
                  rerollPhaseAmount++;
              if(numberConvertedChoiceOfVersion == 3){
                  
              }
              else{
                       if(bulletCount >= 1 &&  numberUserChoiceOldSaloonDice == 2){
                                   System.out.println("BULLET ROLLED APPLICATION:");
                                   Project3.effectedPlayer =  Project3.playersTurn;
                                   System.out.println(Project3.effectedPlayer.player + " has lost a life to a BULLET");
                                   //lose one life point immediately
                                   CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                   bulletAlreadyCalculated = true;
                                   bulletCount--;
                       }
                       if(brokenArrowCount >= 1 &&  numberUserChoiceOldSaloonDice == 1){
                           System.out.println("BROKEN ARROW ROLLED APPLICATION: ");
                            //returns arrow from any player
                                  System.out.println("choose a player to return an arrow from to the arrowstack");
                           if(playersTurn.name.equals(chosenCharacter)){
                                  do{
                                       if(questionCount > 0)
                                            System.out.println(" player not found please try again");
                                           userInput = "";
                                           userInput = scan.nextLine();
                                             userInput = userInput_toString(userInput);
                                             //System.out.println(userInput);
                                             Project3.effectedPlayer = CharacterLinkedList.searchCharacter(userInput,Project3.playersTurn);
                                             //System.out.println(Project3.effectedPlayer.name);
                                             //checks if the effected player's life is at its highest limit.
                                             if( Project3.effectedPlayer != null ){
                                                  if(Project3.effectedPlayer.arrows == 0){
                                                        System.out.println(Project3.effectedPlayer.player + " has no arrows can't take a arrow away");
                                                        playerHasArrows = false;
                                                  }
                                                  else{
                                                        playerHasArrows = true;
                                                  }
                                             }
                                            questionCount++;
                                  }while(Project3.effectedPlayer == null);
                           }
                           else{
                               Project3.effectedPlayer = CharacterLinkedList.searchRandom(randNumber, randDirection);
                           }
                                   questionCount--;
                                  if(playerHasArrows == true){
                                      effectedPlayer.arrows -= 1;
                                      Arrows.arrowPush(Arrows.arrowsStack, 1);
                                      System.out.println(effectedPlayer.player + " now has " + effectedPlayer.arrows + " arrows");
                                  }
                                  else
                                      System.out.println("Broken Arrow wasted!");
                              brokenArrowAlreadyCalculated = true ;
                              brokenArrowCount--;
                       }
              }
                       System.out.println("reroll phase done");
                       System.out.println("*****************************************************************" + "\n" + "dice after rerolls");
                       for(int j = 0; j < diceFacesRolled.length;j++){
                           
                                  System.out.println(diceFacesRolled[j]);
                                  Dice.diceFaceCountReroll[j] = 0;
                       }
                       System.out.println("*****************************************************************");   
                       //checks if they have already rerolled the dice the max number of times for them.
                       //LUCKY DUKE SPECIAL ABILITY IMPLEMENTATION
                       if(Project3.playersTurn.name.equals("LUCKYDUKE")){
                                    if(rerollPhaseAmount == 3 ){
                                         System.out.println("reroll phase over");
                                         rerollTerminated = true;
                                         return;
                                    }
                                    if(rerollPhaseAmount == 2 ){
                                        System.out.println(Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: gets an extra reroll phase");
                                        return;
                                    }
                       }
                       else{
                            if(rerollPhaseAmount == 2){
                                 System.out.println("reroll done");
                                 rerollTerminated = true;
                             }
                       }
                       bulletCount = 0;
                       brokenArrowCount = 0;
                       return;
              default:
                       System.out.println("not a number of a dice please try again");
                       return;
          }
          if(diceFaceCountReroll[index] > 1 ){
              System.out.println("have already rerolled that dice wait for the next reroll phase");
              return;
          }
          //checks if its dynamite
          if("DYNAMITE".equals(diceFacesRolled[index]))
          {
              //BLACK JACK'S SPECIAL ABILITY IMPLMENTED
              if(Project3.playersTurn.name.equals("BLACKJACK")){
                     System.out.println(Project3.playersTurn.name + "'S SPECIAL ABILITY ACTIVATED: he can reroll DYNAMITE");
              }
              else{
                     System.out.println("can't reroll DYNAMITE");
                     return;
               }
          }
          if( numberConvertedChoiceOfVersion == 2 && numberUserChoiceOldSaloonDice == 1 && Project3.userChoiceOfReroll == 1){ //coward dice
                playersRoll = rand.nextInt(6);
                diceFaceString = CowardDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                diceFacesRolled[index] = diceFaceString;
                System.out.println("rerolled dice:");
                System.out.println(numberOfRoll + "." + diceFaceString);   
                if("INDIANARROW".equals(diceFacesRolled[index])){
                        System.out.println("INDIANARROW:");
                        Project3.playersTurn.arrows += 1;
                        System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                        Arrows.stackPop(Arrows.arrowsStack);
                        //check for indian attack
                        Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                }
                if("BROKENARROW".equals(diceFacesRolled[index])){
                      brokenArrowAlreadyCalculated = false;
                      brokenArrowCount++;
                }
          }
          else if( numberConvertedChoiceOfVersion == 2 && numberUserChoiceOldSaloonDice == 2 && Project3.userChoiceOfReroll == 1){ //loudmouth dice
                playersRoll = rand.nextInt(6);
                diceFaceString = LoudMouthDiceFace.getLoudMouthDiceFace(playersRoll).getdiceFace_toString();
                diceFacesRolled[index] = diceFaceString;
                System.out.println("rerolled dice:");
                System.out.println(numberOfRoll + "." + diceFaceString);   
                if("INDIANARROW".equals(diceFacesRolled[index])){
                        System.out.println("INDIANARROW:");
                        Project3.playersTurn.arrows += 1;
                        System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                        Arrows.stackPop(Arrows.arrowsStack);
                        //check for indian attack
                        Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                }
                 if("BULLET".equals(diceFacesRolled[index])){
                       bulletAlreadyCalculated = false;
                       bulletCount++;
                }
          }
          else if(numberConvertedChoiceOfVersion == 3 && (Project3.userChoiceOfReroll == 1 || Project3.userChoiceOfReroll == 2)){ //duel dice
                //System.out.println("in duel dice");
                playersRoll = rand.nextInt(6);
                diceFaceString = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                diceFacesRolled[index] = diceFaceString;
                System.out.println("rerolled dice:");
                System.out.println(numberOfRoll + "." + diceFaceString);   
                if("INDIANARROW".equals(diceFacesRolled[index])){
                        System.out.println("INDIANARROW:");
                        Project3.playersTurn.arrows += 1;
                        System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                        Arrows.stackPop(Arrows.arrowsStack);
                        //check for indian attack
                        Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                }
                if("DUEL".equals(diceFacesRolled[index])){
                    System.out.println("duel count + 1");
                    duelAlreadyAdded = true;
                    duelCount++;
                }
          }
          else if(numberConvertedChoiceOfVersion == 4 && (userChoiceOfReroll == 1 || userChoiceOfReroll == 2 || userChoiceOfReroll == 3)){ //combined version
                //System.out.println("in combined");
                playersRoll = rand.nextInt(6);
                if(userChoiceOfReroll == 1 || userChoiceOfReroll == 2){
                    System.out.println("in combined duel");
                    diceFaceString = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                    diceFacesRolled[index] = diceFaceString;
                    System.out.println("rerolled dice:");
                    System.out.println(numberOfRoll + "." + diceFaceString);   
                    if("INDIANARROW".equals(diceFacesRolled[index])){
                        System.out.println("INDIANARROW:");
                        Project3.playersTurn.arrows += 1;
                        System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                        Arrows.stackPop(Arrows.arrowsStack);
                        //check for indian attack
                        Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                    }
                   if("DUEL".equals(diceFacesRolled[index])){
                       System.out.println("duel count + 1");
                       duelAlreadyAdded = true;
                       duelCount++;
                    }
                }
                else if(userChoiceOfReroll == 3){
                    //System.out.println("in combined userchoiceOf reroll = 3");
                    if(numberUserChoiceOldSaloonDice != 3){
                    if(numberUserChoiceOldSaloonDice == 1){
                          System.out.println("in combined coward");
                            playersRoll = rand.nextInt(6);
                            diceFaceString = CowardDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            diceFacesRolled[index] = diceFaceString;
                            System.out.println("rerolled dice:");
                            System.out.println(numberOfRoll + "." + diceFaceString);   
                            if("INDIANARROW".equals(diceFacesRolled[index])){
                                System.out.println("INDIANARROW:");
                                Project3.playersTurn.arrows += 1;
                                System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                                Arrows.stackPop(Arrows.arrowsStack);
                                //check for indian attack
                                Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                            }
                            if("BROKENARROW".equals(diceFacesRolled[index])){
                                brokenArrowAlreadyCalculated = false;
                                brokenArrowCount++;
                            }   
                    }else if(numberUserChoiceOldSaloonDice == 2){
                         System.out.println("in combined loudmouth");
                         playersRoll = rand.nextInt(6);
                         diceFaceString = LoudMouthDiceFace.getLoudMouthDiceFace(playersRoll).getdiceFace_toString();
                         diceFacesRolled[index] = diceFaceString;
                         System.out.println("rerolled dice:");
                         System.out.println(numberOfRoll + "." + diceFaceString);   
                         if("INDIANARROW".equals(diceFacesRolled[index])){
                            System.out.println("INDIANARROW:");
                            Project3.playersTurn.arrows += 1;
                            System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                            Arrows.stackPop(Arrows.arrowsStack);
                            //check for indian attack
                            Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                        }
                        if("BULLET".equals(diceFacesRolled[index])){
                            bulletAlreadyCalculated = false;
                            bulletCount++;
                        }
                             
                   }
                    
               }else{
                        System.out.println("in combined 3 regular");
                        playersRoll = rand.nextInt(6);
                        diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                        diceFacesRolled[index] = diceFaceString;
                        System.out.println("rerolled dice:");
                        System.out.println(numberOfRoll + "." + diceFaceString);   
                        if("INDIANARROW".equals(diceFacesRolled[index])){
                            System.out.println("INDIANARROW:");
                            Project3.playersTurn.arrows += 1;
                            System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                            Arrows.stackPop(Arrows.arrowsStack);
                            //check for indian attack
                            Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                        } 
                    }
             }
            
          }
          else{  //regular reroll
                playersRoll = rand.nextInt(6);
                diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                diceFacesRolled[index] = diceFaceString;
                System.out.println("rerolled dice:");
                System.out.println(numberOfRoll + "." + diceFaceString);   
                if("INDIANARROW".equals(diceFacesRolled[index])){
                        System.out.println("INDIANARROW:");
                        Project3.playersTurn.arrows += 1;
                        System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                        Arrows.stackPop(Arrows.arrowsStack);
                        //check for indian attack
                        Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack); 
                 
                }
          }
                //checks if there is 3 DYNAMITES rolled already, if so terminates rerolling
                dynamiteCounter = 0;
                for(String diceFacesRolled1 : diceFacesRolled){
                    if (diceFacesRolled1.equals("DYNAMITE")) {
                        dynamiteCounter++;
                    }
                }
               if(dynamiteCounter >= 3){
                        rerollTerminated = true;
                     if(Project3.dynamiteLifeTaken == false){
                         System.out.println(Project3.playersTurn.player + " has rolled 3 DYNAMITE, rerolls are over.");
                         Project3.playersTurn.lifes--;
                         System.out.println(Project3.playersTurn.player + " loses a life due to it, they now have " + Project3.playersTurn.lifes + " life");
                         Project3.dynamiteLifeTaken = true;
                     }
                     else
                     {
                        System.out.println(Project3.playersTurn.player + " has rolled 3 DYNAMITE, rerolls are over.");
                        System.out.println(Project3.playersTurn.player + " life point has already been taken away.");
                     }
              }
          
     }
         
    
   //calculates the total of the dice.
    public static void diceFaceCalculations(String diceFace){
        beerLimitExceeded = false;
        
        switch(diceFace){
            
            case "INDIANARROW": 
                                  diceFaceCount[0]++;
                                  System.out.println("INDIANARROW:");
                                  Project3.playersTurn.arrows += 1;
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                                  Arrows.stackPop(Arrows.arrowsStack);
                                  //check for indian attack
                                  Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack);
                                  diceCalculationsCount++;
                                  break;
            case "DYNAMITE":      
                                  diceFaceCount[1]++;
                                  System.out.println("DYNAMITE:");
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 dynamite, for dynamite they now have a value of " + diceFaceCount[1]);
                                  if( diceFaceCount[1] == 3)
                                  {
                                      if(Project3.dynamiteLifeTaken == false){
                                        Project3.playersTurn.lifes -= 1;
                                        System.out.println( "  " + Project3.playersTurn.player  + " lost a life, since they have rolled 3 DYNAMITE");
                                        diceFaceCount[1] = 0;
                                      }
                                      else{
                                          System.out.println(" life has already been taken away");
                                      }
                                  }
                                  diceCalculationsCount++;
                                  break;
            case "BULLSEYE1":    
                                  diceFaceCount[2]++;
                                  System.out.println("BULLSEYE1:");
                                  System.out.println(" choose a player either left or right one space away");
                                  if(Project3.playersTurn.name.equals(Project3.chosenCharacter)){ //users turn
                                       Project3.effectedPlayer = CharacterLinkedList.searchBullsEyes(1,Project3.playersTurn);
                                       CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                  }
                                  else{ //AI just random rn
                                       int oneSpace = 1;
                                       Project3.effectedPlayer = CharacterLinkedList.searchRandom(oneSpace,randDirection);
                                       CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                  }
                                  diceCalculationsCount++;
                                  break;
            case "BULLSEYE2":  
                                 diceFaceCount[3]++;
                                 System.out.println("BULLSEYE2:");
                                 System.out.println(" choose a player either left or right two spaces away");
                                 if(Project3.playersTurn.name.equals(Project3.chosenCharacter)){ //users turn
                                     if(!(CharacterLinkedList.characterTwoSpacesAway == false)){
                                         Project3.effectedPlayer = CharacterLinkedList.searchBullsEyes(2,Project3.playersTurn);
                                         CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                     }
                                     else{
                                         System.out.println("the player two spaces away is yourself, cant shoot yourself");
                                     }
                                 }
                                 else{ //AI just random rn 
                                      if(!(CharacterLinkedList.characterTwoSpacesAway == false)){
                                         int twoSpace = 2;
                                         Project3.effectedPlayer = CharacterLinkedList.searchRandom(twoSpace,randDirection);
                                         CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                      }
                                      else{
                                           System.out.println("the player two spaces away is yourself, cant shoot yourself");
                                      }
                                 }
                                 diceCalculationsCount++;
                                 break;
            case "BEER":            
                                  questionCount = 0;
                                  System.out.println("BEER:");
                                  diceFaceCount[4]++;
                                  if(Project3.playersTurn.name.equals(Project3.chosenCharacter)){ //users turn
                                      //JESSE JONES SPECIAL ABILITY IMPLEMENTATION
                                       System.out.println(" who would you like to give your beer");
                                    do{
                                       if(questionCount > 0)
                                            System.out.println(" player not found please try again");
                                           userInput = "";
                                           userInput = scan.nextLine();
                                             userInput = userInput_toString(userInput);
                                             //System.out.println(userInput);
                                             Project3.effectedPlayer = CharacterLinkedList.searchCharacter(userInput,Project3.playersTurn);
                                             
                                             //System.out.println(Project3.effectedPlayer.name);
                                             //checks if the effected player's life is at its highest limit.
                                             if( Project3.effectedPlayer != null ){
                                                  if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                                         System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                                         beerLimitExceeded = true;
                                                    }
                                             }
                                            questionCount++;
                                       }while(Project3.effectedPlayer == null);
                                          if(beerLimitExceeded == false){
                                                 if(!(effectedPlayer.role.equals("ZOMBIE"))){
                                                    if(!(Project3.playersTurn.name.equals("JESSEJONES"))){
                                                        CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                                    }
                                                    else{
                                                        System.out.println(Project3.playersTurn.player + "'S SPECIAL MOVE ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                        + Project3.playersTurn.lifes + " life");
                                                        CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                                    }
                                                    
                                              }
                                              else{
                                                  System.out.println("cant use the BEER since they are a zombie, WHISKEY wasted!");
                                              }
                                          } 
                                  }
                                  else{ //AI just random rn
                                        do{
                                            randomNumber3 = rand.nextInt(6);
                                        }while(randomNumber3 == 0);
                                        Project3.effectedPlayer = CharacterLinkedList.searchRandom(randomNumber3,randDirection);
                                      if(!(effectedPlayer.role.equals("ZOMBIE"))){
                                            if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                                 System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                                 beerLimitExceeded = true;
                                            } 
                                            if(beerLimitExceeded == false){ 
                                                if(Project3.playersTurn.name.equals("JESSEJONES") && Project3.effectedPlayer.name.equals("JESSEJONES")){
                                                    System.out.println(Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                     + Project3.playersTurn.lifes + " life");
                                                    CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                                }
                                                else{
                                                    CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                                }
                                            }
                                        }
                                        else{
                                            System.out.println("cant use the BEER since they are a zombie, BEER wasted!");
                                        }
                                  }
                                  diceCalculationsCount++;
                                 break;
            case "GATLINGGUN":  
                                 diceFaceCount[5]++;
                                 System.out.println("GATLINGGUN:");
                                 System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 gatlinggun, for gatlinggun they now have a value of " +  diceFaceCount[5]);
                                 //WILLY THE KID'S SPECIAL MOVE IMPLMENTED
                                 if(Project3.playersTurn.name.equals("WILLYTHEKID"))
                                 {
                                         if( diceFaceCount[5] == 2)
                                         {
                                            System.out.println(" " + Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: they have rolled 2 GATLINGGUN,every other player has lost a life  ");
                                            System.out.println(" " + Project3.playersTurn.player + " has gotten 3 gatling guns every other player has lost a life");
                                            CharacterLinkedList.gatlingGun(Project3.playersTurn);
                                            diceFaceCount[5] = 0;
                                         }
                                 }
                                 else{    
                                         if( diceFaceCount[5] == 3)
                                         {
                                            System.out.println(" " + Project3.playersTurn.player + " has gotten 3 gatling guns every other player has lost a life");
                                            CharacterLinkedList.gatlingGun(Project3.playersTurn);
                                            diceFaceCount[5] = 0;
                                         }
                                 }
                                 diceCalculationsCount++;
                                 break;    
              
            
        }
        //SUZY LAFAYETTE'S SPECIAL ABILITY IMPLEMENTATION
        if(diceCalculationsCount == 6 && Project3.playersTurn.name.equals("SUZYLAFAYETTE")){
                if(diceFaceCount[2] == 0 && diceFaceCount[3] == 0){
                    Project3.effectedPlayer = CharacterLinkedList.searchCharacter("SUZYLAFAYETTE", effectedPlayer);
                    if(Project3.effectedPlayer.lifes + 2 > Project3.effectedPlayer.maxLifes){
                         System.out.println(" " + Project3.effectedPlayer.player + "'S SPECIAL ABILITY ACTIVATED: she has not rolled any BULLSEYE1 or BULLSEYE2," + "\n" + " but adding 2 life is too much for her life max,"
                                  + " so her special ability is wasted");
                    }
                    else{
                         System.out.println(Project3.effectedPlayer + "'S SPECIAL ABILITY ACTIVATED: she has not rolled any BULLSEYE1 or BULLSEYE2, she gains 2 life");
                         CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                    }
                }
        }
   }
    
    public static void cowardDiceFaceCalculations(String diceFace){
          beerLimitExceeded = false;
          doubleSymbol = 0;
         switch(diceFace){
             case "INDIANARROW": 
                                  cowardDiceCount[0]++;
                                  System.out.println("INDIANARROW:");
                                  Project3.playersTurn.arrows += 1;
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                                  Arrows.stackPop(Arrows.arrowsStack);
                                  //check for indian attack
                                  Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack);
                                  diceCalculationsCount++;
                                  break;
             case "BROKENARROW": 
                                  //returns arrow from any player
                                  cowardDiceCount[1]++;
                                   if(brokenArrowAlreadyCalculated == false){
                                    System.out.println("choose a player to return an arrow from to the arrowstack");
                                     do{
                                         if(questionCount > 0)
                                              System.out.println(" player not found please try again");
                                             userInput = "";
                                             userInput = scan.nextLine();
                                              userInput = userInput_toString(userInput);
                                              //System.out.println(userInput);
                                               Project3.effectedPlayer = CharacterLinkedList.searchCharacter(userInput,Project3.playersTurn);
                                              //System.out.println(Project3.effectedPlayer.name);
                                              //checks if the effected player's life is at its highest limit.
                                              if( Project3.effectedPlayer != null ){
                                                    if(Project3.effectedPlayer.arrows == 0){
                                                         System.out.println(Project3.effectedPlayer.player + " has no arrows can't take a arrow away");
                                                         playerHasArrows = false;
                                                   }
                                                   else{
                                                        playerHasArrows = true;
                                                  }
                                                 }
                                            questionCount++;
                                        }while(Project3.effectedPlayer == null);
                                      if(playerHasArrows == true){
                                        effectedPlayer.arrows -= 1;
                                        Arrows.arrowPush(Arrows.arrowsStack, 1);
                                        System.out.println(effectedPlayer.player + " now has " + effectedPlayer.arrows + " arrows");
                                      }
                                      else
                                        System.out.println("Broken Arrow wasted!");
                                   }
                                   else{
                                       System.out.println("Broken Arrow Already used");
                                   }
                                  break;  
            case "DYNAMITE":      
                                  cowardDiceCount[2]++;
                                  System.out.println("DYNAMITE:");
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 dynamite, for dynamite they now have a value of " + cowardDiceCount[1]);
                                  if(cowardDiceCount[2] == 3)
                                  {
                                      if(Project3.dynamiteLifeTaken == false){
                                        Project3.playersTurn.lifes -= 1;
                                        System.out.println( "  " + Project3.playersTurn.player  + " lost a life, since they have rolled 3 DYNAMITE");
                                       cowardDiceCount[2] = 0;
                                      }
                                      else{
                                          System.out.println(" life has already been taken away");
                                      }
                                  }
                                  diceCalculationsCount++;
                                  break;
            case "BULLSEYE1":    
                                 cowardDiceCount[3]++;
                                  System.out.println("BULLSEYE1:");
                                  System.out.println(" choose a player either left or right one space away");
                                  if(Project3.playersTurn.name.equals(Project3.chosenCharacter)){ //users turn
                                       Project3.effectedPlayer = CharacterLinkedList.searchBullsEyes(1,Project3.playersTurn);
                                       CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                  }
                                  else{ //AI just random rn
                                       int oneSpace = 1;
                                       Project3.effectedPlayer = CharacterLinkedList.searchRandom(oneSpace,randDirection);
                                       CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                  }
                                  diceCalculationsCount++;
                                  break;
              case "BEER":            
                                  questionCount = 0;
                                  System.out.println("BEER:");
                                  cowardDiceCount[4]++;
                                  if(Project3.playersTurn.name.equals(Project3.chosenCharacter)){ //users turn
                                      //JESSE JONES SPECIAL ABILITY IMPLEMENTATION
                                       System.out.println(" who would you like to give your beer");
                                    do{
                                       if(questionCount > 0)
                                            System.out.println(" player not found please try again");
                                           userInput = "";
                                           userInput = scan.nextLine();
                                             userInput = userInput_toString(userInput);
                                             //System.out.println(userInput);
                                             Project3.effectedPlayer = CharacterLinkedList.searchCharacter(userInput,Project3.playersTurn);
                                             
                                             //System.out.println(Project3.effectedPlayer.name);
                                             //checks if the effected player's life is at its highest limit.
                                             if( Project3.effectedPlayer != null ){
                                                  if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                                         System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                                         beerLimitExceeded = true;
                                                    }
                                             }
                                            questionCount++;
                                       }while(Project3.effectedPlayer == null);
                                          if(beerLimitExceeded == false){
                                              if(!(Project3.playersTurn.name.equals("JESSEJONES"))){
                                                    CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                              }
                                              else{
                                                   System.out.println(Project3.playersTurn.player + "'S SPECIAL MOVE ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                   + Project3.playersTurn.lifes + " life");
                                                   CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                              }
                                          } 
                                  }
                                  else{ //AI just random rn
                                        do{
                                            randomNumber3 = rand.nextInt(6);
                                        }while(randomNumber3 == 0);
                                        Project3.effectedPlayer = CharacterLinkedList.searchRandom(randomNumber3,randDirection);
                                        if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                               System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                               beerLimitExceeded = true;
                                        } 
                                        if(beerLimitExceeded == false){ 
                                            if(Project3.playersTurn.name.equals("JESSEJONES") && Project3.effectedPlayer.name.equals("JESSEJONES")){
                                                System.out.println(Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                   + Project3.playersTurn.lifes + " life");
                                                CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                            }
                                            else{
                                                CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                            }
                                        }
                                  }
                                  diceCalculationsCount++;
                                 break;
             case "DOUBLEBEER":            
                                  
                                  System.out.println("DOUBLEBEER:");
                                  cowardDiceCount[4]++;
                            do{
                                  questionCount = 0;
                                  if(Project3.playersTurn.name.equals(Project3.chosenCharacter)){ //users turn
                                      //JESSE JONES SPECIAL ABILITY IMPLEMENTATION
                                       System.out.println(" who would you like to give your beer");
                                    do{
                                       if(questionCount > 0)
                                            System.out.println(" player not found please try again");
                                           userInput = "";
                                           userInput = scan.nextLine();
                                             userInput = userInput_toString(userInput);
                                             //System.out.println(userInput);
                                             Project3.effectedPlayer = CharacterLinkedList.searchCharacter(userInput,Project3.playersTurn);
                                             
                                             //System.out.println(Project3.effectedPlayer.name);
                                             //checks if the effected player's life is at its highest limit.
                                             if( Project3.effectedPlayer != null ){
                                                  if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                                         System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                                         beerLimitExceeded = true;
                                                    }
                                             }
                                            questionCount++;
                                       }while(Project3.effectedPlayer == null);
                                          if(beerLimitExceeded == false){
                                              if(!(Project3.playersTurn.name.equals("JESSEJONES"))){
                                                    CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                              }
                                              else{
                                                   System.out.println(Project3.playersTurn.player + "'S SPECIAL MOVE ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                   + Project3.playersTurn.lifes + " life");
                                                   CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                              }
                                          } 
                                  }
                                  else{ //AI just random rn
                                        do{
                                            randomNumber3 = rand.nextInt(6);
                                        }while(randomNumber3 == 0);
                                        Project3.effectedPlayer = CharacterLinkedList.searchRandom(randomNumber3,randDirection);
                                        if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                               System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                               beerLimitExceeded = true;
                                        } 
                                        if(beerLimitExceeded == false){ 
                                            if(Project3.playersTurn.name.equals("JESSEJONES") && Project3.effectedPlayer.name.equals("JESSEJONES")){
                                                System.out.println(Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                   + Project3.playersTurn.lifes + " life");
                                                CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                            }
                                            else{
                                                CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                            }
                                        }
                                  }
                                  doubleSymbol++;
                            }while(doubleSymbol != 2);     
                                  diceCalculationsCount++;
                                 break;
         }
        
    }
    public static void loudMouthDiceCalulations(String diceFace){
        doubleSymbol = 0;
        
        switch(diceFace){
            case "INDIANARROW": 
                                  loudMouthDiceCount[0]++;
                                  System.out.println("INDIANARROW:");
                                  Project3.playersTurn.arrows += 1;
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                                  Arrows.stackPop(Arrows.arrowsStack);
                                  //check for indian attack
                                  Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack);
                                  diceCalculationsCount++;
                                  break;
        
            case "BULLET":    
                                  loudMouthDiceCount[1]++;
                                  if(bulletAlreadyCalculated == false){
                                    System.out.println("BULLET:");
                                    Project3.effectedPlayer =  Project3.playersTurn;
                                    System.out.println(Project3.effectedPlayer.player + " has lost a life to a BULLET");
                                    //lose one life point immediately
                                    CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                    System.out.println(Project3.effectedPlayer.player + " now has " + Project3.effectedPlayer.lifes + " life" );
                                  }
                                  else{
                                      System.out.println("Bullet already accounted for");
                                  }
                                  break;
            case "DYNAMITE":      
                                  loudMouthDiceCount[2]++;
                                  System.out.println("DYNAMITE:");
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 dynamite, for dynamite they now have a value of " + loudMouthDiceCount[2]);
                                  if( loudMouthDiceCount[2] == 3)
                                  {
                                      if(Project3.dynamiteLifeTaken == false){
                                        Project3.playersTurn.lifes -= 1;
                                        System.out.println( "  " + Project3.playersTurn.player  + " lost a life, since they have rolled 3 DYNAMITE");
                                        loudMouthDiceCount[2] = 0;
                                      }
                                      else{
                                          System.out.println(" life has already been taken away");
                                      }
                                  }
                                  diceCalculationsCount++;
                                  break;
            case "DOUBLEBULLSEYE1":  System.out.println("DOUBLEBULLSEYE1:");  
                                    do{
                                        loudMouthDiceCount[3]++;
                                        System.out.println("choose a player either left or right one space away");
                                        Project3.effectedPlayer = CharacterLinkedList.searchBullsEyes(1,Project3.playersTurn);
                                        CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                         doubleSymbol++;
                                    }while(doubleSymbol != 2);  
                                    break;
            case "DOUBLEBULLSEYE2":
                                      System.out.println("DOUBLEBULLSEYE2:");
                                     do{
                                        loudMouthDiceCount[4]++;
                                        System.out.println("choose a player either left or right two spaces away");
                                        Project3.effectedPlayer = CharacterLinkedList.searchBullsEyes(2,Project3.playersTurn);
                                        CharacterLinkedList.dealDamage(Project3.effectedPlayer, 1);
                                        doubleSymbol++;
                                    }while(doubleSymbol != 2);  
                                    break;
            case "DOUBLEGATLINGGUN":  
                                    loudMouthDiceCount[5]++;
                                    loudMouthDiceCount[5]++;
                                    System.out.println("GATLINGGUN:");
                                    System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 gatlinggun, for gatlinggun they now have a value of " +  loudMouthDiceCount[5]);
                                    //WILLY THE KID'S SPECIAL MOVE IMPLMENTED
                                    if(Project3.playersTurn.name.equals("WILLYTHEKID"))
                                    {
                                         if(loudMouthDiceCount[5] == 2)
                                         {
                                            System.out.println(" " + Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: they have rolled 2 GATLINGGUN,every other player has lost a life  ");
                                            System.out.println(" " + Project3.playersTurn.player + " has gotten 3 gatling guns every other player has lost a life");
                                            CharacterLinkedList.gatlingGun(Project3.playersTurn);
                                            loudMouthDiceCount[5] = 0;
                                         }
                                    }
                                    else{    
                                         if( loudMouthDiceCount[5] == 3)
                                         {
                                            System.out.println(" " + Project3.playersTurn.player + " has gotten 3 gatling guns every other player has lost a life");
                                            CharacterLinkedList.gatlingGun(Project3.playersTurn);
                                            loudMouthDiceCount[5] = 0;
                                         }
                                    }
                                   diceCalculationsCount++;
                                    break;    
                                    
        }
    }
    public static void duelDiceCalculations(String diceFace){
        boolean whiskeyLimitExceeded = false;
        switch(diceFace){
            case "INDIANARROW": 
                                  duelDiceCount[0]++;
                                  System.out.println("INDIANARROW:");
                                  Project3.playersTurn.arrows += 1;
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 arrow, for arrows they now have a value of " + Project3.playersTurn.arrows);
                                  Arrows.stackPop(Arrows.arrowsStack);
                                  //check for indian attack
                                  Arrows.indiansAttack(Arrows.arrowsStack,Project3.ArrowAttack);
                                  diceCalculationsCount++;
                                  break;
              
            case "DYNAMITE":      
                                  duelDiceCount[1]++;
                                  System.out.println("DYNAMITE:");
                                  System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 dynamite, for dynamite they now have a value of " + duelDiceCount[1]);
                                  if(duelDiceCount[1] == 3)
                                  {
                                      if(Project3.dynamiteLifeTaken == false){
                                        Project3.playersTurn.lifes -= 1;
                                        System.out.println( "  " + Project3.playersTurn.player  + " lost a life, since they have rolled 3 DYNAMITE");
                                        duelDiceCount[1] = 0;
                                      }
                                      else{
                                          System.out.println(" life has already been taken away");
                                      }
                                  }
                                  diceCalculationsCount++;
                                  break;                      
        
            case "WHISKEYBOTTLE":
                                 duelDiceCount[2]++;
                                 //GREG DIGGERS SPECIAL ABILITY IMPLEMENTATION
                                 if(Project3.playersTurn.name.equals("GREGDIGGER")){
                                      System.out.println("GREGDIGGER'S SPECIAL ABILITY ACTIVATED, THEY GET TO USE WHISKEYBOTTLE TWICE");
                                      System.out.println("WHISKEYBOTTLE:");
                                      System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 WHISKEY");
                                     effectedPlayer = Project3.playersTurn;
                                     if(!(effectedPlayer.role.equals("ZOMBIE"))){
                                         if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                             System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                            whiskeyLimitExceeded = true;
                                        }
                                        if(whiskeyLimitExceeded = false)
                                         CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                        if(!(Project3.playersTurn.duelWoundLink.isEmpty())){
                                            Project3.playersTurn.duelWoundLink.remove();
                                        System.out.println("a battle wound has been removed due to the whiskey");
                                        }
                                        }
                                        else{
                                            System.out.println("cant use the WHISKEY since they are a zombie, WHISKEY wasted!");
                                        }
                                 }
                                 System.out.println("WHISKEYBOTTLE:");
                                 System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 WHISKEY");
                                 effectedPlayer = Project3.playersTurn;
                                 if(!(effectedPlayer.role.equals("ZOMBIE"))){
                                    if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                        System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                        whiskeyLimitExceeded = true;
                                    }
                                    if(whiskeyLimitExceeded = false)
                                         CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                     if(!(Project3.playersTurn.duelWoundLink.isEmpty())){
                                        Project3.playersTurn.duelWoundLink.remove();
                                        System.out.println("a battle wound has been removed due to the whiskey");
                                    }
                                 }
                                 else{
                                     System.out.println("cant use the WHISKEY since they are a zombie, WHISKEY wasted!");
                                 }
                                 break;
                                 
                                  
            case "BEER":            
                                  questionCount = 0;
                                  System.out.println("BEER:");
                                  duelDiceCount[3]++;
                                  if(Project3.playersTurn.name.equals(Project3.chosenCharacter)){ //users turn
                                      //JESSE JONES SPECIAL ABILITY IMPLEMENTATION
                                       System.out.println(" who would you like to give your beer");
                                    do{
                                       if(questionCount > 0)
                                            System.out.println(" player not found please try again");
                                           userInput = "";
                                           userInput = scan.nextLine();
                                             userInput = userInput_toString(userInput);
                                             //System.out.println(userInput);
                                             Project3.effectedPlayer = CharacterLinkedList.searchCharacter(userInput,Project3.playersTurn);
                                             
                                             //System.out.println(Project3.effectedPlayer.name);
                                             //checks if the effected player's life is at its highest limit.
                                             if( Project3.effectedPlayer != null ){
                                                  if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                                         System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                                         beerLimitExceeded = true;
                                                    }
                                             }
                                            questionCount++;
                                       }while(Project3.effectedPlayer == null);
                                          if(beerLimitExceeded == false){
                                                if(!(effectedPlayer.role.equals("ZOMBIE"))){
                                                    if(!(Project3.playersTurn.name.equals("JESSEJONES"))){
                                                        CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                                    }
                                                    else{
                                                        System.out.println(Project3.playersTurn.player + "'S SPECIAL MOVE ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                        + Project3.playersTurn.lifes + " life");
                                                        CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                                    }
                                                    
                                              }
                                              else{
                                                  System.out.println("cant use the BEER since they are a zombie, WHISKEY wasted!");
                                              }
                                          } 
                                  }
                                  else{ //AI just random rn
                                        do{
                                            randomNumber3 = rand.nextInt(6);
                                        }while(randomNumber3 == 0);
                                        Project3.effectedPlayer = CharacterLinkedList.searchRandom(randomNumber3,randDirection);
                                        if(!(effectedPlayer.role.equals("ZOMBIE"))){
                                            if(Project3.effectedPlayer.lifes + 1 > Project3.effectedPlayer.maxLifes){
                                                 System.out.println(Project3.effectedPlayer.player + " has reached their max number of lifes, Beer Wasted!");
                                                 beerLimitExceeded = true;
                                            } 
                                            if(beerLimitExceeded == false){ 
                                                if(Project3.playersTurn.name.equals("JESSEJONES") && Project3.effectedPlayer.name.equals("JESSEJONES")){
                                                    System.out.println(Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: since they are healing themselves with 4 life points or less they get 2 life back, they now have "
                                                     + Project3.playersTurn.lifes + " life");
                                                    CharacterLinkedList.heal(Project3.effectedPlayer, 2);
                                                }
                                                else{
                                                    CharacterLinkedList.heal(Project3.effectedPlayer, 1);
                                                }
                                            }
                                        }
                                        else{
                                            System.out.println("cant use the BEER since they are a zombie, BEER wasted!");
                                        }
                                  }
                                  diceCalculationsCount++;
                                 break;
            
            case "GATLINGGUN":  
                                duelDiceCount[4]++;
                                 System.out.println("GATLINGGUN:");
                                 System.out.println(" " + Project3.playersTurn.player + " has gotten + 1 gatlinggun, for gatlinggun they now have a value of " + duelDiceCount[4]);
                                 //WILLY THE KID'S SPECIAL MOVE IMPLMENTED
                                 if(Project3.playersTurn.name.equals("WILLYTHEKID"))
                                 {
                                         if( duelDiceCount[4] == 2)
                                         {
                                            System.out.println(" " + Project3.playersTurn.player + "'S SPECIAL ABILITY ACTIVATED: they have rolled 2 GATLINGGUN,every other player has lost a life  ");
                                            System.out.println(" " + Project3.playersTurn.player + " has gotten 3 gatling guns every other player has lost a life");
                                            CharacterLinkedList.gatlingGun(Project3.playersTurn);
                                            duelDiceCount[4] = 0;
                                         }
                                 }
                                 else{    
                                         if( duelDiceCount[4] == 3)
                                         {
                                            System.out.println(" " + Project3.playersTurn.player + " has gotten 3 gatling guns every other player has lost a life");
                                            CharacterLinkedList.gatlingGun(Project3.playersTurn);
                                            duelDiceCount[4] = 0;
                                         }
                                 }
                                 diceCalculationsCount++;
                                 break;    
            case "DUEL":    
                                duelDiceCount[5]++;
                                if(duelAlreadyAdded == false)
                                      duelCount++;
                                if(duelActive == false){
                                    System.out.println("DUEL:");
                                    System.out.println("duels will be activated at the end of your turn");
                                }
                                else{
                                    System.out.println("rolled a duel face");
                                }
                                
        }
      
    }
    //will take the users input and make input into a format that can be compared to the Chracters name.
    public static String userInput_toString(String userInput){
        
        userInput = userInput.toUpperCase();
        userInput = userInput.replaceAll( " ", "");  
        userInput = userInput.replaceAll("_","");
        
        
        return userInput;
    }
    
    
}
