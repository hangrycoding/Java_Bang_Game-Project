
package project3;
import java.util.LinkedList;
import java.util.Scanner;
import static project3.Node.*;
/**
 *
 * @author Dylan Lowman
 * 
 * 
 */
public class CharacterLinkedList {
    static protected Node start = null;
    static protected Node end = null;
    static protected Node currentNode = null;
    static private Node leftPlayer = null;
    static private Node rightPlayer = null;
    static String userInput;
    static Scanner scan = new Scanner(System.in);
    static boolean characterTwoSpacesAway = true;
    //inserts all the characters chosen into the list.
   public static void insert(Character player, String name, int lifes,String role,int arrows,boolean revealedRole, int maxLifes,String lifeStatus,LinkedList duelWoundLink)
   {
       Node node = new Node(); //creates a new node
       node.player = player;//specifies that these paremters are linked to the variables inside the node
       node.name = name;
       node.lifes = lifes;
       node.role = role;
       node.arrows = arrows;
       node.revealedRole = revealedRole;
       node.maxLifes = maxLifes;
       node.lifeStatus = lifeStatus;
       node.duelWoundLink = duelWoundLink;
       node.prev = null;
       node.next = null;
       
       if(start == null){
           start = node;
           node.next = start;
           node.prev = end;
       }
       else{
           currentNode = start;
           
           while(currentNode.next != start){
               
               currentNode = currentNode.next;
           }
           node.prev = currentNode;
           currentNode.next = node;
           end = node;
           node.next = start;
           start.prev = end;
           
       }
       
    
   }
   //gives the user the names of the people they can shoot, takes the user input and subtracts 1 life from the chracter of their choice.
   public static Node searchBullsEyes(int bullseyeNumber,Node playersTurn){
       int count = 0;
       Node effectedPlayer = null;
       characterTwoSpacesAway = false;
       
       if(start == null)
           System.out.println(" no players");
       else{
                //for the bullseye1
                if(bullseyeNumber == 1){
                    leftPlayer = playersTurn.prev;
                    rightPlayer = playersTurn.next;
                    System.out.println(" who would you like to shoot " + leftPlayer.player + " or " + rightPlayer.player + " ?");
                    do{
                        if(count > 0)
                            System.out.println(" player not found, please try again");
                        userInput = scan.nextLine();
                        userInput = userInput.toUpperCase();
                        userInput = userInput.replaceAll( " ", "");  
                        userInput = userInput.replaceAll("_","");
                        //System.out.println("userInput" + userInput + " leftPlayer" + leftPlayer.name + " rightPlayer" + rightPlayer.name);
                        count++;
                    }while(!(userInput.equals(leftPlayer.name)) && !(userInput.equals(rightPlayer.name)));
                    if(userInput.equals(leftPlayer.name))
                        effectedPlayer = leftPlayer;
                    else 
                        effectedPlayer = rightPlayer;
                    
                }
                else{   //for bullseye2
                        leftPlayer = playersTurn.prev.prev;
                        rightPlayer = playersTurn.next.next;
                        System.out.println(" who would you like to shoot " + leftPlayer.player + " or " + rightPlayer.player + " ?");
                        //checks if it is current PlayersTurn turn 
                        if((leftPlayer.name.equals(Project3.playersTurn.name)) && (rightPlayer.name.equals(Project3.playersTurn.name))){
                            System.out.println("no players two spaces away at the moment");
                        }
                        else{
                            characterTwoSpacesAway = true;
                            do{
                                 if(count > 0)
                                 System.out.println(" player not found, please try again");
                                 userInput = scan.nextLine();
                                 userInput = userInput.toUpperCase();
                                 userInput = userInput.replaceAll( " ", "");  
                                 userInput = userInput.replaceAll("_","");
                                 //System.out.println("userInput" + userInput + " leftPlayer" + leftPlayer.name + " rightPlayer" + rightPlayer.name);
                                 count++;
                             }while(!(userInput.equals(leftPlayer.name)) && !(userInput.equals(rightPlayer.name)));
                            if(userInput.equals(leftPlayer.name))
                                effectedPlayer = leftPlayer;
                            else 
                                effectedPlayer = rightPlayer;
                        }
                }
         }
       return effectedPlayer;
  }
   // for the AI
    public static Node searchRandom(int randNumber,int direction){ 
       int count = 0;
       Node currentNode = start; 
       
        if(start == null)
           System.out.println("no nodes available");
       else{
            if(direction == 1){    //direction right
              do{
                  currentNode = currentNode.next;
                  count++;
                  
               }while(count != randNumber);
            }
            else{        //direction left               
                do{
                  currentNode = currentNode.next;
                  count++;
                  
               }while(count != randNumber);
            }
        }
           // System.out.println("player found");
           // System.out.println("player:" + currentNode.player + "   Lifes:" + currentNode.lifes + "  Role:" + currentNode.role + "  Arrows:"  + currentNode.arrows);
            
            return currentNode;
   }
    //search for Character Object in the game will continue to run until they pick a character in the game
    public static Node searchCharacter(String player,Node effectedPlayer){
        boolean playerFound = false;
        
        effectedPlayer = start;
        do{ 
            effectedPlayer = effectedPlayer.next;
            //System.out.println("current player name" + currentNode.name);
            if(effectedPlayer.name.equals(player)){
                playerFound = true;
            }
        }while( playerFound == false && effectedPlayer != start);
        if(playerFound == true){
            //System.out.println("player found");
           // System.out.println("player:" + currentNode.player + "   Lifes:" + currentNode.lifes + "  Role:" + currentNode.role + "  Arrows:"  + currentNode.arrows);
            return effectedPlayer;
        }
        else
            return null;
      
    }
    //find the first person of a specific role, for the AI to find specific roles to heal and damage
    //need to fix to return a node that can then be healed or damaged
  public static void searchRole(String playerRole){  
       Node currentNode = start; 
       boolean correctPlayer = false;
       
        if(start == null)
           System.out.println("No nodes available");
       else{
              do{
                  
                  if(currentNode.role.contains(playerRole))
                     correctPlayer = true;
                  else
                  {
                      //System.out.println("hi3");
                      currentNode = currentNode.next;
                  }
                  if(currentNode.next == start)
                  {
                      if(currentNode.role.contains(playerRole))
                        {
                            //System.out.println("hi2");
                             correctPlayer = true;
                        }
                      
                  }
                      
                  
               }while(correctPlayer != true && currentNode.next != start);
              
        }
        if(correctPlayer == true){
            System.out.println("player found");
            System.out.println("player:" + currentNode.player + "   Lifes:" + currentNode.lifes + "  Role:" + currentNode.role + "  Arrows:"  + currentNode.arrows);
        }else
            System.out.println("player not found");
   }
  //shows the list of everybody in the game
   public static void show()
   {
       currentNode = start;
          
       do{

           if(currentNode.revealedRole == false){
                 if(currentNode.name.equals(Project3.chosenCharacter))
                     System.out.println( "YOUR PLAYER:" +  currentNode.player + "   Lifes:" +  currentNode.lifes + "  Role:UNKNOWN" + "  Arrows:"  +  currentNode.arrows + " " + currentNode.lifeStatus );
                 else
                     System.out.println("PLAYER:" +  currentNode.player + "   Lifes:" +  currentNode.lifes + "  Role:UNKNOWN" + "  Arrows:"  +  currentNode.arrows+ " " + currentNode.lifeStatus );
           }
           else{
                 if(currentNode.name.equals(Project3.chosenCharacter))
                     System.out.println("YOUR PLAYER:" +  currentNode.player + "   Lifes:" +  currentNode.lifes + "  Role:" +  currentNode.role + "  Arrows:"  +  currentNode.arrows+ " " + currentNode.lifeStatus );
                 else
                     System.out.println("PLAYER:" +  currentNode.player + "   Lifes:" +  currentNode.lifes + "  Role:" +  currentNode.role + "  Arrows:"  +  currentNode.arrows+ " " + currentNode.lifeStatus );
           }
           currentNode = currentNode.next; 
           
       }while(currentNode != start);
        
   }
   //gatling gun takes away one life from everybody else and removes the player's arrows who rolled it to 0.
    public static void gatlingGun(Node playerTurn)
   {
       int arrowsTakenAway;
        currentNode = playerTurn;
       
        do{ 
            if(currentNode == playerTurn){
                arrowsTakenAway = currentNode.arrows;
                currentNode.arrows = 0;
                System.out.println("  due to the effects of rolling 3 gatlingguns " + currentNode.player + " now has " + currentNode.arrows + " arrows");
                // adds the correct amount of arrows back on the stack.
                Arrows.arrowPush(Arrows.arrowsStack, arrowsTakenAway);

            }
            currentNode = currentNode.next;
            //SPECIAL ABILITY OF PAUL REGRET IMPLEMENTED
            if(!(currentNode.name.equals("PAULREGRET"))){
                 currentNode.lifes -= 1;
                 System.out.println( " "+ currentNode.player + " has lost one life due to the gatlinggun, they now have " + currentNode.lifes + " lifes");
            }
            else{
                System.out.println(" " + currentNode.player + "'S SPECIAL ABILITY ACTIVATED: he does not take any damage to the GATLINGGUN");
            }
        }while(currentNode.next != playerTurn);
       
        
   }
   //checks what players need to be eliminated after indian attack or person deals damage.
   public void deletePlayers(Node ArrowAttack)
   {
       
       ArrowAttack = start;
 
       do{
           if(ArrowAttack.lifes <= 0){
                 
                 leftPlayer = ArrowAttack.prev;
                 rightPlayer = ArrowAttack.next;
                 
                 //System.out.println("leftplayer " + leftPlayer.player +" rightplayer " + rightPlayer.player);
      
                 if(ArrowAttack == start){
                     start = rightPlayer;
                 }
                 if(ArrowAttack == end){
                     end = leftPlayer;
                 }
                 leftPlayer.next = rightPlayer;
                 rightPlayer.prev = leftPlayer;
                 //add them to the graveYard
                 //keeps on breaking since zombie outbreak happened and have not reset all variables of start and stuff
                 //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                 DeadList.insert(ArrowAttack.player,ArrowAttack.name,"Dead",ArrowAttack.role,0);
                 //checks if the player who dies is the player, currently playing their turn 
                 //using the show function for testing suspecting that the last node is not completely removed so 
                 //when trying to insert another dead player into the list it doesnt have any links to add it to
                 // the list
                 DeadList.show();
                 if(ArrowAttack.name.equals(Project3.chosenCharacter))
                 {
                    //checks if the character who dies is the users character.
                    System.out.println("YOUR PLAYER " + ArrowAttack.player + " HAS DIED YOU LOSE!!");
                    if(ArrowAttack == Project3.playersTurn){
                     //checks if its the character's who's current turn it is dies
                     Project3.turnTerminated = true;
                     System.out.println(" your turn is terminated next players turn" + "\n");
                     }
                     System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                     System.out.println("press enter to continue");
                     scan.nextLine();
                 }
                 else{
                    //for a character who is not the user and who's not turn it is
                     System.out.println(ArrowAttack.player + " WAS ELIMINATED, their role was " + ArrowAttack.role);
                     if(ArrowAttack == Project3.playersTurn){
                     //checks if its the character's who's current turn it is dies
                     Project3.turnTerminated = true;
                     System.out.println(" their turn is terminated next players turn" + "\n");
                     }
                     System.out.println("press enter to continue the game");
                     scan.nextLine();
                 }
           }
           
         
           ArrowAttack = ArrowAttack.next; 
           
       }while(ArrowAttack != start);
       
   }
  
   //used to deal the right amount of damage to a character's life points.
   public static int dealDamage(Node effectedPlayer,int damage){
       
       effectedPlayer.lifes -= damage;
       System.out.println(effectedPlayer.player + " has lost " + damage + " life, they currently have " + effectedPlayer.lifes + " lifes");
      
     return effectedPlayer.lifes;
       
   }
   //used to add the right amount of health to a character's life points.
   public static int heal(Node effectedPlayer,int heal){
       
      effectedPlayer.lifes += heal;
      System.out.println(effectedPlayer.player + " has been given " + heal +  " life, they now have " + effectedPlayer.lifes + " lifes");
       
      return effectedPlayer.lifes;
       
   }

}
