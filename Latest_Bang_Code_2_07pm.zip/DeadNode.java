/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;

/**
 *
 * @author Dylan Lowman
 */
public class DeadNode {
    Character player;//enum of the character
    String name;
    String lifeStatus;
    String role;
    int valueZombieCard;
    DeadNode prev;//pointer for the prev node
    DeadNode next;//pointer for the next node
    
}
