
package project3;
/**
 *
 * @author Dylan Lowman
 */
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/*
 * windows communicating with each other
 */

/**
 *
 * @author Dylan Lowman
 */
public class ConfirmBox {
    
       static boolean answer;
    
      public static boolean display(String title, String message){
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(title);
        stage.setMinWidth(250);
        Label label = new Label();
        label.setText(message);
        
        //create two buttons 
        Button yesButton = new Button("Yes");
        yesButton.setOnAction(e -> {
            answer = true;
            stage.close();
        });
        Button noButton = new Button("No");
        noButton.setOnAction(e -> {
            answer = false;
            stage.close();
        });
        
        VBox layout = new VBox(10);
        layout.getChildren().addAll(label,noButton,yesButton);
        layout.setAlignment(Pos.CENTER);
        
        //Scene
        Scene scene = new Scene(layout);
        stage.setScene(scene); //adds the scene to the window
        stage.showAndWait(); //displays the window and until it returns the main function must be closed 
        
        return answer;
    }
    
}
