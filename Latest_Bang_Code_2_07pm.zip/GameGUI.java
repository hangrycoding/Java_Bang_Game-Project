/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;

import project3.ConfirmBox;
import project3.AlertBox;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;

public class GameGUI extends Application{
    static Stage stage;
    Scene scene1,scene2;
    Button button,button2,button3,button4,button5,buttonCharacter,buttonCheckBox;
    ComboBox<String> comboBox;
    TreeView<String> tree;

   
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("BangFXML.fxml"));
        stage = primaryStage; 
        //stage title
        stage.setTitle("BANG! GAME");
        //stage closes on action of pressing the x button
        stage.setOnCloseRequest(e -> {
            e.consume();// tells the system we are gonna implement some code
            closeProgram();
                });
        
        Label label1 = new Label("Welcome to BANG!");
        //button1
        button = new Button("go to scene 2");
        //e lamda allows the action of switching to a view of the scene2
        button.setOnAction(e -> stage.setScene(scene2));
        //button2
        button2 = new Button("hello");
        //e lamda allows the action of switching to a view of the scene2
        button2.setOnAction(e -> stage.setScene(scene1));
        //button3, sends you to the alertBox
        button3 = new Button("alertBox");
        button3.setOnAction(e -> AlertBox.display("Title of the window","alert Box are awesome"));
        //button4 
        button4 = new Button("See Naked Pics");
        button4.setOnAction(e -> {
           boolean result = ConfirmBox.display("Boobies","Nice Boobies");
           System.out.println(result);
        });
        //button5 
        button5 = new Button("close program");
        button5.setOnAction(e -> {
            closeProgram();
            stage.close();
                });
        //checkBoxes 
        CheckBox box1 = new CheckBox("BANG!");
        CheckBox box2 = new CheckBox("Old Saloon");
        CheckBox box3 = new CheckBox("Undead or Alive");
        //checks it by default 
         //button hadleCheckbox
        buttonCheckBox = new Button("enter version");
        buttonCheckBox.setOnAction(e -> {
            handleCheckBox(box1,box2,box3);
        });
        box1.setSelected(true);
        //layout1,vertical column
        HBox topMenu = new HBox(20);
        topMenu.getChildren().addAll(label1,button,button3,button4,button5);
        //layout2
        VBox leftMenu = new VBox();
        leftMenu.getChildren().add(button2);
        //layout3
        //BorderPane
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(topMenu);
        /*borderPane.setCenter(box1);
        borderPane.setLeft(box2);
        borderPane.setRight(buttonCheckBox);*/
        //creating a drop down list 
        //gridpane 
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10,10,10,10));
        grid.setVgap(8);
        grid.setHgap(10);
        //welcome label
        Label welcomeLabel = new Label("Welcome to Bang! please select the version of the game you would like to play!");
        GridPane.setConstraints(welcomeLabel,1,1);
        //name label to tell users to choose a character
        Label nameLabel = new Label("Choose your character:");
        GridPane.setConstraints(nameLabel,1,17);
        //Name input
        /*TextField characterInput = new TextField();
        GridPane.setConstraints(characterInput,1,18);//middle: column  right: row
         buttonCharacter.setOnAction(e ->{
            System.out.println(characterInput.getText());
            
        });*/
         //Button6
        GridPane.setConstraints(buttonCheckBox,1,6);
        GridPane.setConstraints(box1,1,2);
        GridPane.setConstraints(box2,1,3);
        GridPane.setConstraints(box3,1,4);
        ChoiceBox<String> characterChoice = new ChoiceBox();
        characterChoice.getItems().addAll("Black Jack","Jesse Jones","Jourdonnais","Lucky Duke",
                "Paul Regret","Suzy Lafayette","Willy the Kid","Greg Digger","Belle Star","Jose Delgado","Tequila Joe");
        GridPane.setConstraints(characterChoice,1,18);
        buttonCharacter = new Button("enter character");
        buttonCharacter.setOnAction(e -> {
            handleCharacterDropDown(characterChoice);
        });
        GridPane.setConstraints(buttonCharacter,1,19);//middle: column  right: row
        //add to the grid
        grid.getChildren().addAll(nameLabel,buttonCharacter,welcomeLabel,box1,box2,box3,buttonCheckBox,characterChoice);
        
        
        //Listen for selection changes
        characterChoice.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> v,String oldValue,String newValue)-> System.out.println(newValue));
        
        
        //attach the stage to the scene
        //stage.setScene(new Scene(root, 300, 275));
        scene1 = new Scene(grid, 1000, 500);
        scene1.getStylesheets().add(getClass().getResource("Bang.css").toExternalForm());
        scene2 = new Scene(borderPane, 1000, 500);
        stage.setScene(scene1);
        stage.setTitle("BANG!");
        stage.show();
    }
    
    public static void closeProgram(){
        Boolean answer = ConfirmBox.display("title"," are u sure you want to exit");
        System.out.println("file saved");
        if(answer == true){
            stage.close();
        }
    }
    public static void handleCheckBox(CheckBox box1, CheckBox box2, CheckBox box3){
        String message = "Version: ";
        
        if(box1.isSelected()){
           System.out.println("base game");
        }
        if(box2.isSelected()){
            System.out.println("old saloon");
        }
        if(box3.isSelected()){
            System.out.println("undead or alive");
        }
        
        
    }
    public static void handleCharacterDropDown(ChoiceBox<String> characterChoice){
        String character = characterChoice.getValue();
        System.out.println(character);
    }
}
