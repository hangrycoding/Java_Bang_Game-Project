
/*
 * A Single Player take on the strategy card game called BANG!. 
 */
package project3;

import java.util.LinkedList;
import java.util.Random;
import project3.Character.*;
import java.util.Scanner;
import project3.Dice.*;
import project3.Arrows.*;
import java.util.Stack;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;
import static project3.Dice.numberOfCalculation;
import project3.GameGUI.*;

/**
 *
 * @author Dylan Lowman
 */
public abstract class Project3{
    //used for more than 3 players, needs to be fixed is not random so starting player is always sheriff and so on
    static String roles[] = {"SHERIFF","RENEGADE","OUTLAW","OUTLAW","DEPUTY","OUTLAW","DEPUTY","RENEGADE"};
    //tells the users of the special abilities of each character must be in order of the characters listed
    static String textOfSpecials[] = {"You may re-roll DYNAMITE(not if you roll three or more!).","If you have four life points or less, you gain two if you use BEER for yourself."
            ,"You never lose more than one life point to Indians","You may make one extra re-roll.","You never lose life points to the GATLINGGUN."
            ,"If you didn’t roll any BULLSEYE1 or BULLSEYE2, you gain two life points. This only applies at the end of your turn, not during your re-rolls."
            ,"You only need 2 GATLINGGUN to use the GATLINGGUN. You can activate the GATLINGGUN only once per turn, even if you roll more than 2 GATLINGGUN results."
            ,"You may use each WHISKEY you roll twice","After each of your dice rolls, you can change one DYNAMITE to GATLINGUN (Not if you roll three or more !). "
            ,"You may use the Loudmouth die without replacing a base die (roll six dice total).","You may use the Coward die without replacing a base die (roll six dice total)."};
    //variable for the users player
    static String chosenCharacter,checkCharacter,computerPlayerName,userPlayerName,usersInput,promptUserRoll,diceFaceString,numberReroll,choiceOfVersion,userChoiceOldSaloonDice,challengersRoll,defenderRoll;
    //keeps track of which characters are in the game so no repeats occur
    static boolean[] inGame = new boolean[16];
    //keeps track what dicefaces are rolled for the entire turn
    static String[] diceFacesRolled = new String[6];
    //variables that are used as arguments
    static int duelDiceCalculated,randNumber,randNumber2,randdirection,randBullsEye,damage,heal,playersRoll,generatedNumberCount,numberOfRoll = 1,whichDiceReroll,userChoiceOfReroll,zombieOutbreakCount=0,numberConvertedChoiceOfVersion,numberUserChoiceOldSaloonDice,
            oldSaloonDiceNumber,computerChoiceOfReroll,computerChoiceOfOldSaloonDice;
    //keeps track of number or rounds,how many times a question has been prompted, what index is the users character,how many times the dice is rolled 
    static int roundCount = 0, promptQuestion = 0, userCharacterIndex = -1,timesRolled = 0,dynamiteCount = 0,oldSaloonDiceChoice = 0,oldSaloonDiceApplication = 0,duelDiceCount = 0;
    //keeps track of whos turn it is by intervaling through the linked list, or some of them are used to apply damage or heal players
    static Node playersTurn, usersTurn, effectedPlayer,ArrowAttack;
    static boolean gameOver,roundOver,existingCharacter,userAdded,rollDone,revealedRole,dynamiteLifeTaken,turnTerminated,isNumber,mainStartZombieOutbreak,validVersion,validOldSaloonDice,duelActive,duelOver;
    //characacter Object keeps track of user character
    static Character userCharacter;
    
    
    public static void main(String[] args) {
        //launches the GAMEGUI 
        
        GameGUI GUI = new GameGUI();
        Application.launch(GameGUI.class,args);
       /*************************************************************************************************************************************************************************
        *  sets everything up for the start of the game                                                                                                                         
        *  prompts user for info                                                                                                                                                *
        *  adds user and characters to the circular linked list                                                                                                                 *                                                                                                                                                                    *
        *************************************************************************************************************************************************************************/
       //asks what expansions the player wants to play with
       Scanner scan = new Scanner(System.in);
       Scanner scan2 = new Scanner(System.in);
       System.out.println("Welcome to BANG!!!" + "\n" + "Please select what version of the game you would like to play");
       System.out.println("1.BANG!" + "\n" + "2.Old Saloon" + "\n" + "3.Undead or Alive" + "\n" + "4. All of them" + "\n");
       do{
           try{
          
                  choiceOfVersion = scan.nextLine();
                  numberConvertedChoiceOfVersion = Integer.parseInt(choiceOfVersion);
                  validVersion = true;
            }catch(NumberFormatException v){
               validVersion = false;
               System.out.println("not a valid version please try again");
            }
           
       }while(validVersion == false);
       System.out.println("************************************************************************************************************");
       //adds created data-structure
       CharacterLinkedList CharacterList = new CharacterLinkedList();  
       
       //generates random number of A.I. including the user 4-8
       
       Random rand = new Random();
       do{
           randNumber = rand.nextInt(9);
       }while(randNumber <= 3);
       //System.out.println("number of players: " + randNumber);
       Character[] players = new Character[11];
       System.out.println(" CHARACTERS: ");
       System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
       //adds the characters to a player array
       for(int i = 0; i < players.length;i++){
           
           players[i] = new Character(Characters.getCharacter(i));
           System.out.println(players[i].toString());
           System.out.println("special ability: " + textOfSpecials[i]);
           System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
       }
       //adds user player, then adds the A.I players randomly from the player array
       //prompts the user to pick a character
       System.out.println("pick a character" + "\n" + "\n");
        do{
            userCharacterIndex = -1;
            chosenCharacter = scan2.nextLine();
            chosenCharacter = chosenCharacter.toUpperCase();
            chosenCharacter = chosenCharacter.replaceAll( " ", "");  
            chosenCharacter = chosenCharacter.replaceAll("_","");
            for(int i = 0; i < players.length;i++){
                
                checkCharacter = players[i].toString();
                checkCharacter = checkCharacter.replaceAll("_", "");
                checkCharacter = checkCharacter.replaceAll(" ", "");
                if(checkCharacter.equals(chosenCharacter)){
                    System.out.print("character has been chosen" + "\n" + "\n");
                    userCharacter = players[i];
                    existingCharacter = true;
                    userCharacterIndex++;
                }
                if(existingCharacter != true)
                   userCharacterIndex++;
            }
            if(existingCharacter == false)
                System.out.print("player not found please try again" + "\n");
        }while(existingCharacter == false);
       
       //adds the characters and users to the circular linked list, can be modifies to where index is random 
       //but for now user always the starting player
       for(int j = 0; j < randNumber;j++){
           while(userAdded != true){
               userPlayerName = userCharacter.toString();
               userPlayerName = userPlayerName.replaceAll("_", "");
               userPlayerName = userPlayerName.replaceAll(" ", "");
               //allows other people to see the player's role who is the sheriff
               if(roles[j].equals("SHERIFF"))
                   revealedRole = true;
               else 
                   revealedRole = false;
               CharacterList.insert(userCharacter,userPlayerName,Characters.getCharacter(userCharacterIndex).getLifes(),roles[j],0,revealedRole,Characters.getCharacter(userCharacterIndex).getLifes(),"Alive",new LinkedList());
               userAdded = true;
               inGame[userCharacterIndex] = true;
               j++;
           }
           do{ 
               randNumber2 = rand.nextInt(11);
           }while(inGame[randNumber2] == true);
           //takes away the spaces and makes the AI name just capital alphabetical so it can be easier to find
           computerPlayerName = Characters.getCharacter(randNumber2).toString();
           computerPlayerName = computerPlayerName.replaceAll("_", "");
           computerPlayerName = computerPlayerName.replaceAll(" ", "");
            if(roles[j].equals("SHERIFF"))
                   revealedRole = true;
               else 
                   revealedRole = false;
           CharacterList.insert(players[randNumber2],computerPlayerName,Characters.getCharacter(randNumber2).getLifes(),roles[j],0,revealedRole,Characters.getCharacter(randNumber2).getLifes(),"Alive",new LinkedList());
           System.out.println("competitor chosen: " + players[randNumber2]);
           inGame[randNumber2] = true;
       }
       if(numberConvertedChoiceOfVersion == 1){
       //pushes all the arrows onto the stack for the start of the game
       Arrows.arrowPush(Arrows.arrowsStack,9);
       //makes the first peron in the linked list the start
       playersTurn = CharacterList.start;
       System.out.println("\n" + " players in the game ");
       CharacterList.show();
       
      

       
       System.out.println("\n");
       
       /************************************************************************************************************************************************************************************
       *  //start of the logic for the game                                                                                                                                                *                                                                                                                                                                       *
       ************************************************************************************************************************************************************************************/
       System.out.println("\n" + " START OF GAME "); 
       while(gameOver == false)
       {
          
           //controls the rounds 
           while(roundOver == false){
                System.out.println("_____________________________________");
                if(playersTurn.revealedRole == false)
                System.out.println("\n" + "ROLE:UNKNOWN " + playersTurn.player + " turn: ");
                else
                System.out.println("\n" + "ROLE:" + playersTurn.role + " " + playersTurn.player + " turn: ");
               //resets all variables for the next players
                timesRolled = 0;
                dynamiteCount = 0;
                dynamiteLifeTaken = false;
                turnTerminated = false;
                Dice.rerollPhaseAmount = 0;
                //users turn
                if(playersTurn.name.equals(chosenCharacter)){
                    //System.out.println("playersTurn name: " + playersTurn.name + " usersTurn name: " + chosenCharacter);
                         System.out.println("press enter to roll dice for your turn:" );
                         System.out.println("***********************************************");
                         promptUserRoll = scan.nextLine();
                       //rolls the dice for the user
                       numberOfRoll = 1;
                        do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            if(diceFaceString.equals("DYNAMITE"))
                                dynamiteCount++;
                            diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString);
                            timesRolled++;
                            numberOfRoll++;
                            
                        }while(timesRolled  != 6);
                        //checks if there is already 3 dynamites rolled for rerolls
                        if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                            do{
                                 
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done with this reroll phase.");
                               
                                 do{
                                     numberReroll = scan.nextLine();
                                     try{
                                         userChoiceOfReroll = -1;
                                         userChoiceOfReroll = Integer.parseInt(numberReroll);
                                         isNumber = true;
                                   }catch(NumberFormatException e){
                                     isNumber = false;
                                   }
                                 }while(!(isNumber = true));
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                           
                                  System.out.println(diceFacesRolled[j]);
                                  Dice.diceFaceCountReroll[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                        System.out.println("***********************************************");
                        System.out.println("results:");
                        //allows the user to use the diceFaces they rolled
                        if(turnTerminated == false){
                            for(int i = 0;i < diceFacesRolled.length;i++){ 
                                gameOver = winConditions.checkWinConditions();
                                if(gameOver == true)
                                    break;
                                diceFaceString = diceFacesRolled[i];
                                Dice.diceFaceCalculations(diceFaceString);
                                //removes player if needed after every calculation occurs
                                CharacterList.deletePlayers(ArrowAttack);
                                if(turnTerminated == true)
                                    break;
                                
                            }
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){       
                            Dice.diceFaceCount[i] = 0;
                        }  
                }
                else{          
                                //A.I.'s Turn
                        System.out.println( "\n" + "press enter to see" + playersTurn.player + " results" );
                        System.out.println("***********************************************");
                        promptUserRoll = scan.nextLine();
                        //rolls the dice for the AI
                        numberOfRoll = 1;
                        do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString);
                            timesRolled++;
                            numberOfRoll++;
                            
                        }while(timesRolled  != 6);
                         if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                            do{
                                 
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done with this reroll phase.");
                                 do{
                                    userChoiceOfReroll = rand.nextInt(8);
                                 }while(userChoiceOfReroll == 0);
                                 System.out.println(userChoiceOfReroll);
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                           
                                  System.out.println(diceFacesRolled[j]);
                                  Dice.diceFaceCountReroll[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                         System.out.println("***********************************************");
                          //allows the AI to use the diceFaces they rolled
                        for(int i = 0;i < diceFacesRolled.length;i++){ 
                            gameOver = winConditions.checkWinConditions();
                            if(gameOver == true)
                                break;     
                            diceFaceString = diceFacesRolled[i];
                            Dice.diceFaceCalculations(diceFaceString);
                            //removes player if needed after every calculation occurs
                            CharacterList.deletePlayers(ArrowAttack);
                            if(turnTerminated ==  true)
                               break;
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){       
                            
                            Dice.diceFaceCount[i] = 0;
                        }
                }
             gameOver = winConditions.checkWinConditions();
             if(gameOver == true)
                  break;
              playersTurn = playersTurn.next;
              if(playersTurn == CharacterList.start){ 
                  roundOver = true;
              }
           }
           if(gameOver == true)
                 break;
           roundCount++;
           roundOver = false;
           System.out.println("_____________________________________");
           System.out.println("\n" + " end of round " + roundCount);
           System.out.println("\n" + "Remaining players");
           CharacterList.show();
           DeadList.show();
           
          }
           System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
           System.out.println("GAME OVER"); 
       
    }
    else if(numberConvertedChoiceOfVersion == 2){
        //pushes all the arrows onto the stack for the start of the game
       Arrows.arrowPush(Arrows.arrowsStack,9);
       //makes the first peron in the linked list the start
       playersTurn = CharacterList.start;
       System.out.println("\n" + " players in the game ");
       CharacterList.show();
       
      

       
       System.out.println("\n");
       
       /************************************************************************************************************************************************************************************
       *  //start of the logic for the game old saloon                                                                                                                                             *                                                                                                                                                                       *
       ************************************************************************************************************************************************************************************/
       System.out.println("\n" + " START OF GAME "); 
       while(gameOver == false)
       {
          
           //controls the rounds 
           while(roundOver == false){
                System.out.println("_____________________________________");
                if(playersTurn.revealedRole == false)
                System.out.println("\n" + "ROLE:UNKNOWN " + playersTurn.player + " turn: ");
                else
                System.out.println("\n" + "ROLE:" + playersTurn.role + " " + playersTurn.player + " turn: ");
               //resets all variables for the next players
                timesRolled = 0;
                dynamiteCount = 0;
                oldSaloonDiceNumber = 0;
                numberUserChoiceOldSaloonDice = 0;
                oldSaloonDiceApplication = 0;
                oldSaloonDiceChoice = 0;
                dynamiteLifeTaken = false;
                turnTerminated = false;
                Dice.rerollPhaseAmount = 0;
                //users turn
                if(playersTurn.name.equals(chosenCharacter)){
                        System.out.println("press to roll: "+ "\n" + "1: Coward Dice " + "\n" + "2: LoudMouth Dice" + "\n" + "3: roll all regular dice");
                         do{
                                try{
                                        do{
                                            if(oldSaloonDiceChoice >= 1)
                                            System.out.println("not a valid dice please try again");
                                            userChoiceOldSaloonDice = scan.nextLine();
                                            numberUserChoiceOldSaloonDice = Integer.parseInt(userChoiceOldSaloonDice);
                                            validOldSaloonDice = true;
                                            oldSaloonDiceChoice++;
                                        }while(numberUserChoiceOldSaloonDice != 1 && numberUserChoiceOldSaloonDice != 2 && numberUserChoiceOldSaloonDice != 3);
                                    }catch(NumberFormatException v){
                                        validOldSaloonDice = false;
                                        System.out.println("not a valid dice please try again");
                                    }  
                        }while(validOldSaloonDice == false);
                         System.out.println("press enter to roll dice for your turn:" );
                         System.out.println("***********************************************");
                         promptUserRoll = scan.nextLine();
                       //rolls the dice for the user
                       numberOfRoll = 1;
                       if(numberUserChoiceOldSaloonDice != 3){
                           if(numberUserChoiceOldSaloonDice == 1){
                               oldSaloonDiceNumber = 1;
                               playersRoll = rand.nextInt(6);
                               diceFaceString = CowardDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                               if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                               diceFacesRolled[timesRolled] = diceFaceString;
                               System.out.println( numberOfRoll + "." + diceFaceString  + "(Coward Dice)");
                               timesRolled++;
                               numberOfRoll++;
                           }
                           else if(numberUserChoiceOldSaloonDice == 2){
                               oldSaloonDiceNumber = 2;
                               playersRoll = rand.nextInt(6); 
                               diceFaceString = LoudMouthDiceFace.getLoudMouthDiceFace(playersRoll).getdiceFace_toString();
                               if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                               diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println( numberOfRoll + "." + diceFaceString + "(LoudMouth Dice)");
                               timesRolled++;
                               numberOfRoll++;
                           }
                           do{
                                playersRoll = rand.nextInt(6);
                                diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println(numberOfRoll + "." + diceFaceString);
                                timesRolled++;
                                numberOfRoll++;
                            
                             }while(timesRolled  != 6);
                       }
                       else{
                            do{
                                playersRoll = rand.nextInt(6);
                                diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println(numberOfRoll + "." + diceFaceString);
                                timesRolled++;
                                numberOfRoll++;
                            
                             }while(timesRolled  != 6);
                       }
                        //checks if there is already 3 dynamites rolled for rerolls
                        if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                            do{
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done.");
                               
                                 do{
                                     numberReroll = scan.nextLine();
                                     try{
                                         userChoiceOfReroll = -1;
                                         userChoiceOfReroll = Integer.parseInt(numberReroll);
                                         isNumber = true;
                                   }catch(NumberFormatException e){
                                     isNumber = false;
                                   }
                                 }while(!(isNumber = true));
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                           
                                  System.out.println(diceFacesRolled[j]);
                                  Dice.diceFaceCountReroll[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                        System.out.println("***********************************************");
                        System.out.println("results:");
                        //allows the user to use the diceFaces they rolled
                        if(turnTerminated == false){
                            for(int i = 0;i < diceFacesRolled.length;i++){ 
                                gameOver = winConditions.checkWinConditions();
                                if(gameOver == true)
                                    break;
                                if(numberUserChoiceOldSaloonDice != 3 && oldSaloonDiceApplication == 0){
                                    if(numberUserChoiceOldSaloonDice == 1){
                                        diceFaceString = diceFacesRolled[i];
                                        Dice.cowardDiceFaceCalculations(diceFaceString);
                                        oldSaloonDiceApplication++;
                                    }
                                    else if(numberUserChoiceOldSaloonDice == 2){
                                        diceFaceString = diceFacesRolled[i];
                                        Dice.loudMouthDiceCalulations(diceFaceString);
                                        oldSaloonDiceApplication++;
                                    }
                                }
                                else{
                                    diceFaceString = diceFacesRolled[i];
                                    Dice.diceFaceCalculations(diceFaceString);
                                }  
                                 //removes player if needed after every calculation occurs
                                 CharacterList.deletePlayers(ArrowAttack);
                                 if(turnTerminated == true)
                                    break;
                                
                            }
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){       
                            Dice.diceFaceCount[i] = 0;
                            Dice.cowardDiceCount[i] = 0;
                            Dice.loudMouthDiceCount[i] = 0;
                        }  
                        
                }
                else{          
                                //A.I.'s Turn
                        System.out.println( "\n" + "press enter to see" + playersTurn.player + " results" );
                        System.out.println("***********************************************");
                        promptUserRoll = scan.nextLine();
                        //rolls the dice for the AI
                           do{
                                  numberUserChoiceOldSaloonDice = rand.nextInt(4);
                            }while( numberUserChoiceOldSaloonDice == 0);
                        numberOfRoll = 1;
                        if(numberUserChoiceOldSaloonDice != 3){
                           if(numberUserChoiceOldSaloonDice == 1){
                               oldSaloonDiceNumber = 1;
                               playersRoll = rand.nextInt(6);
                               diceFaceString = CowardDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                               if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                               diceFacesRolled[timesRolled] = diceFaceString;
                               System.out.println( numberOfRoll + "." + diceFaceString  + "(Coward Dice)");
                               timesRolled++;
                               numberOfRoll++;
                           }
                           else if(numberUserChoiceOldSaloonDice == 2){
                               oldSaloonDiceNumber = 2;
                               playersRoll = rand.nextInt(6); 
                               diceFaceString = LoudMouthDiceFace.getLoudMouthDiceFace(playersRoll).getdiceFace_toString();
                               if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                               diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println( numberOfRoll + "." + diceFaceString + "(LoudMouth Dice)");
                               timesRolled++;
                               numberOfRoll++;
                           }
                           do{
                                playersRoll = rand.nextInt(6);
                                diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println(numberOfRoll + "." + diceFaceString);
                                timesRolled++;
                                numberOfRoll++;
                            
                             }while(timesRolled  != 6);
                       }
                       else{
                            do{
                                playersRoll = rand.nextInt(6);
                                diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println(numberOfRoll + "." + diceFaceString);
                                timesRolled++;
                                numberOfRoll++;
                            
                             }while(timesRolled  != 6);
                       }
                        if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                            do{
                                 
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done with this reroll phase.");
                                 do{
                                    userChoiceOfReroll = rand.nextInt(8);
                                 }while(userChoiceOfReroll == 0);
                                 System.out.println(userChoiceOfReroll);
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                           
                                  System.out.println(diceFacesRolled[j]);
                                  Dice.diceFaceCountReroll[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                         System.out.println("***********************************************");
                          //allows the AI to use the diceFaces they rolled
                        for(int i = 0;i < diceFacesRolled.length;i++){ 
                            gameOver = winConditions.checkWinConditions();
                            if(gameOver == true)
                                break;     
                            diceFaceString = diceFacesRolled[i];
                            Dice.diceFaceCalculations(diceFaceString);
                            //removes player if needed after every calculation occurs
                            CharacterList.deletePlayers(ArrowAttack);
                            if(turnTerminated ==  true)
                               break;
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){       
                            
                            Dice.diceFaceCount[i] = 0;
                        }
                }
             gameOver = winConditions.checkWinConditions();
             if(gameOver == true)
                  break;
              playersTurn = playersTurn.next;
              if(playersTurn == CharacterList.start){ 
                  roundOver = true;
              }
           }
           if(gameOver == true)
                 break;
           roundCount++;
           roundOver = false;
           System.out.println("_____________________________________");
           System.out.println("\n" + " end of round " + roundCount);
           System.out.println("\n" + "Remaining players");
           CharacterList.show();
           DeadList.show();
           
          }
           System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
           System.out.println("GAME OVER"); 
       
    }
    else if(numberConvertedChoiceOfVersion == 3){
       //pushes all the arrows onto the stack for the start of the game
       Arrows.arrowPush(Arrows.arrowsStack,9);
       //makes the first peron in the linked list the start
       playersTurn = CharacterList.start;
       System.out.println("\n" + " players in the game ");
       CharacterList.show();
       
      

       
       System.out.println("\n");
       
       /************************************************************************************************************************************************************************************
       *  //start of the logic for the Undead  version                                                                                                                                              *                                                                                                                                                                       *
       ************************************************************************************************************************************************************************************/
       System.out.println("\n" + " START OF GAME "); 
       while(gameOver == false)
       {
          
           //controls the rounds 
           while(roundOver == false){
                System.out.println("_____________________________________");
                if(playersTurn.revealedRole == false)
                System.out.println("\n" + "ROLE:UNKNOWN " + playersTurn.player + " turn: ");
                else
                System.out.println("\n" + "ROLE:" + playersTurn.role + " " + playersTurn.player + " turn: ");
               //resets all variables for the next player
               timesRolled = 0;
                duelDiceCalculated = 0;
                dynamiteCount = 0;
                duelDiceCount = 0;
                duelActive = false;
                duelOver = false;
                Dice.duelCount = 0;
                DuelWoundToken.battleWoundTokenActivated = false;
                Dice.questionCount = 0;
                Dice.numberOfCalculation = 0;
                Dice.rerollPhaseAmount = 0;
                Dice.duelAlreadyAdded = false;
                dynamiteLifeTaken = false;
                turnTerminated = false;
                //users turn
                if(playersTurn.name.equals(chosenCharacter)){
                    //System.out.println("playersTurn name: " + playersTurn.name + " usersTurn name: " + chosenCharacter);
                         System.out.println("press enter to roll dice for your turn:" );
                         System.out.println("***********************************************");
                         promptUserRoll = scan.nextLine();
                       //rolls the dice for the user
                       numberOfRoll = 1;
                        do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            if(diceFaceString.equals("DYNAMITE"))
                            dynamiteCount++;
                            diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString + "(Duel Dice)");
                            timesRolled++;
                            numberOfRoll++;
                            duelDiceCount++;
                         }while(duelDiceCount != 2);
                       do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            if(diceFaceString.equals("DYNAMITE"))
                                dynamiteCount++;
                            diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString);
                            timesRolled++;
                            numberOfRoll++;
                            
                        }while(timesRolled  != 6);
                        //checks if there is already 3 dynamites rolled for rerolls
                        if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                            do{
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done.");
                               
                                 do{
                                     numberReroll = scan.nextLine();
                                     try{
                                         userChoiceOfReroll = -1;
                                         userChoiceOfReroll = Integer.parseInt(numberReroll);
                                         isNumber = true;
                                   }catch(NumberFormatException e){
                                     isNumber = false;
                                   }
                                 }while(!(isNumber = true));
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                                  Dice.diceFaceCountReroll[j] = 0;
                                  Dice.duelDiceCount[j] = 0;
                                  Dice.diceFaceCount[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                        System.out.println("***********************************************");
                        System.out.println("results:");
                        //allows the user to use the diceFaces they rolled
                        if(turnTerminated == false){
                            for(int i = 0;i < diceFacesRolled.length;i++){
                               gameOver = winConditions.checkWinConditions();
                               if(gameOver == true)
                                  break;
                                Dice.numberOfCalculation++;
                                if(duelDiceCalculated != 2){
                                     diceFaceString = diceFacesRolled[i];
                                     Dice.duelDiceCalculations(diceFaceString);
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     duelDiceCalculated++; 
                                }
                                else{
                                     diceFaceString = diceFacesRolled[i];
                                     Dice.diceFaceCalculations(diceFaceString);
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     if(Dice.numberOfCalculation == 6 && Dice.duelCount != 0){
                                         duelActive = true;
                                          do{
                                                System.out.println("Duel initiated:");
                                                System.out.println("choose a person to do battle with");
                                                Dice.questionCount = 0;
                                                do{
                                                    if(Dice.questionCount > 0)
                                                    System.out.println(" player not found please try again");
                                                    Dice.userInput = "";
                                                    Dice.userInput = scan.nextLine();
                                                    Dice.userInput = Dice.userInput_toString(Dice.userInput);
                                                    //System.out.println(userInput);
                                                    Project3.effectedPlayer = CharacterLinkedList.searchCharacter(Dice.userInput,Project3.playersTurn);
                                                    //System.out.println(Project3.effectedPlayer.name);
                                                    //checks if the effected player's life is at its highest limit.
                                                    if(Project3.effectedPlayer != null ){
                                                        System.out.println("****************************************************");
                                                        System.out.println(Project3.effectedPlayer.player + " has been challenged to a duel" + "\n" + "press enter continue");
                                                    //let other player roll dice 
                                                    do{
                                                        System.out.println(Project3.effectedPlayer.player + " roll:");
                                                        playersRoll = rand.nextInt(6);
                                                        defenderRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                        System.out.println(defenderRoll);
                                                        if(defenderRoll.equals("DUEL")){
                                                            System.out.println(Project3.playersTurn.player + " rolled DUEL now the challengers turn");
                                                            System.out.println(Project3.playersTurn.player + " roll:");
                                                            playersRoll = rand.nextInt(6);
                                                            challengersRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                              System.out.println(challengersRoll);
                                                            if(challengersRoll.equals("DUEL")){
                                                             System.out.println(Project3.playersTurn.player + " rolled DUEL now the defenders turn");
                                                            }
                                                            else{
                                                                System.out.println(Project3.playersTurn.player + " has lost the duel");
                                                                DuelWoundToken.giveBattleWound(Project3.playersTurn);
                                                                duelOver = true;
                                                            }
                                                        }
                                                        else{
                                                            System.out.println(Project3.effectedPlayer.player + " has lost the duel");
                                                             DuelWoundToken.giveBattleWound(Project3.effectedPlayer);
                                                            duelOver = true;
                                                        }
                                                           
                                                        
                                                    }while(duelOver == false);
                                                    
                                                            //if the character rolls a duel then pass on to the player who challenged them and let them battle
                                                            //until somebody doesnt roll a duel give the loser a battle wound token
                                                    }
                                                    Dice.questionCount++;
                                                 }while(Project3.effectedPlayer == null);
                                             Dice.questionCount--;
                                             Dice.duelCount--;
                                         }while(Dice.duelCount != 0);
                                     }
                            }
                            if(turnTerminated == true)
                                break;
                            }   
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){      
                                  Dice.diceFaceCountReroll[i] = 0;
                                  Dice.duelDiceCount[i] = 0;
                                  Dice.diceFaceCount[i] = 0;
                        }
                }
                else{          
                                //A.I.'s Turn
                        System.out.println( "\n" + "press enter to see" + playersTurn.player + " results" );
                        System.out.println("***********************************************");
                        promptUserRoll = scan.nextLine();
                        //rolls the dice for the AI
                        numberOfRoll = 1;
                         do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            if(diceFaceString.equals("DYNAMITE"))
                            dynamiteCount++;
                           diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString + "(Duel Dice)");
                            timesRolled++;
                            numberOfRoll++;
                            duelDiceCount++;
                         }while(duelDiceCount != 2);
                       do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            if(diceFaceString.equals("DYNAMITE"))
                                dynamiteCount++;
                            diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString);
                            timesRolled++;
                            numberOfRoll++;
                        }while(timesRolled  != 6);
                        if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                            do{
                                 
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done with this reroll phase.");
                                 do{
                                    userChoiceOfReroll = rand.nextInt(8);
                                 }while(userChoiceOfReroll == 0);
                                 System.out.println(userChoiceOfReroll);
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                           
                                  System.out.println(diceFacesRolled[j]);
                                  Dice.diceFaceCountReroll[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                         System.out.println("***********************************************");
                          //allows the AI to use the diceFaces they rolled
                        for(int i = 0;i < diceFacesRolled.length;i++){       
                             gameOver = winConditions.checkWinConditions();
                             if(gameOver == true){
                               break;
                             }
                              Dice.numberOfCalculation++;
                             if(duelDiceCalculated != 2){
                                     diceFaceString = diceFacesRolled[i];
                                     //checks for the battle wound token calculations
                                     DuelWoundToken.calculateBattleWound(diceFaceString);
                                     if(!(DuelWoundToken.battleWoundTokenActivated == true))
                                        Dice.duelDiceCalculations(diceFaceString);
                                     else {
                                         System.out.println(diceFaceString + " has been canceled due to a battle wound");
                                         DuelWoundToken.battleWoundTokenActivated = false;
                                     }
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     duelDiceCalculated++; 
                                }
                                else{
                                     diceFaceString = diceFacesRolled[i];
                                      //checks for the battle wound token calculations
                                     DuelWoundToken.calculateBattleWound(diceFaceString);
                                     if(!(DuelWoundToken.battleWoundTokenActivated == true))
                                       Dice.diceFaceCalculations(diceFaceString);
                                     else {
                                         System.out.println(diceFaceString + " has been canceled due to a battle wound");
                                         DuelWoundToken.battleWoundTokenActivated = false;
                                     }
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     if(Dice.numberOfCalculation == 6 && Dice.duelCount != 0){
                                         duelActive = true;
                                          do{
                                                System.out.println("Duel initiated:");
                                                System.out.println("choose a person to do battle with");
                                                Dice.questionCount = 0;
                                                do{
                                                    //A.I searches for duel partner
                                                    Project3.effectedPlayer = CharacterLinkedList.searchRandom(1,1);
                                                    //System.out.println(Project3.effectedPlayer.name);
                                                    if(Project3.effectedPlayer != null ){
                                                        System.out.println("****************************************************");
                                                        System.out.println(Project3.effectedPlayer.player + " has been challenged to a duel" + "\n" + "press enter continue");
                                                    //let other player roll dice 
                                                    do{
                                                        System.out.println(Project3.effectedPlayer.player + " roll:");
                                                        playersRoll = rand.nextInt(6);
                                                        defenderRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                        System.out.println(defenderRoll);
                                                        if(defenderRoll.equals("DUEL")){
                                                            System.out.println(Project3.playersTurn.player + " rolled DUEL now the challengers turn");
                                                            System.out.println(Project3.playersTurn.player + " roll:");
                                                            playersRoll = rand.nextInt(6);
                                                            challengersRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                            if(challengersRoll.equals("DUEL")){
                                                             System.out.println(Project3.playersTurn.player + " rolled DUEL now the defenders turn");
                                                            }
                                                            else{
                                                                System.out.println(Project3.playersTurn.player + " has lost the duel");
                                                                DuelWoundToken.giveBattleWound(Project3.playersTurn);
                                                                duelOver = true;
                                                            }
                                                        }
                                                        else{
                                                            System.out.println(Project3.effectedPlayer.player + " has lost the duel");
                                                             DuelWoundToken.giveBattleWound(Project3.effectedPlayer);
                                                            duelOver = true;
                                                        }
                                                           
                                                        
                                                    }while(duelOver == false);
                                                    
                                                            //if the character rolls a duel then pass on to the player who challenged them and let them battle
                                                            //until somebody doesnt roll a duel give the loser a battle wound token
                                                    }
                                                 }while(Project3.effectedPlayer == null);
                                             Dice.duelCount--;
                                         }while(Dice.duelCount != 0);
                                     }
                            }
                            if(turnTerminated ==  true)
                               break;
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){       
                            
                            Dice.diceFaceCount[i] = 0;
                        }
                }
             gameOver = winConditions.checkWinConditions();
             if(gameOver == true)
                 break;
              playersTurn = playersTurn.next; 
              if(playersTurn == CharacterList.start){ 
                  roundOver = true;
              }
           }
           if(gameOver == true)
               break;
           roundCount++;
           roundOver = false;
           System.out.println("_____________________________________");
           System.out.println("\n" + " end of round " + roundCount);
           DuelWoundToken.removeBattleWoundTokens(ArrowAttack);
           System.out.println("\n" + "Remaining players");
           CharacterList.show();
           DeadList.show();
           if(zombieOutbreakCount == 0) 
                mainStartZombieOutbreak = DeadList.checkZombieOutbreak();
           if(DeadList.zombieOutbreakStart == true && zombieOutbreakCount == 0){
               if(mainStartZombieOutbreak = true){
                   DeadList.bringZombiesInGame();
               }
               zombieOutbreakCount++;
               CharacterList.show();
           }
           
       }
           System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
           System.out.println("GAME OVER"); 
    }
    else{
         //pushes all the arrows onto the stack for the start of the game
       Arrows.arrowPush(Arrows.arrowsStack,9);
       //makes the first peron in the linked list the start
       playersTurn = CharacterList.start;
       System.out.println("\n" + " players in the game ");
       CharacterList.show();
       
      

       
       System.out.println("\n");
       
       /************************************************************************************************************************************************************************************
       *  //start of the logic for the combined version                                                                                                                                              *                                                                                                                                                                       *
       ************************************************************************************************************************************************************************************/
       System.out.println("\n" + " START OF GAME "); 
       while(gameOver == false)
       {
          
           //controls the rounds 
           while(roundOver == false){
                System.out.println("_____________________________________");
                if(playersTurn.revealedRole == false)
                System.out.println("\n" + "ROLE:UNKNOWN " + playersTurn.player + " turn: ");
                else
                System.out.println("\n" + "ROLE:" + playersTurn.role + " " + playersTurn.player + " turn: ");
               //resets all variables for the next player
               timesRolled = 0;
                duelDiceCalculated = 0;
                dynamiteCount = 0;
                duelDiceCount = 0;
                duelActive = false;
                duelOver = false;
                Dice.duelCount = 0;
                DuelWoundToken.battleWoundTokenActivated = false;
                Dice.questionCount = 0;
                Dice.numberOfCalculation = 0;
                Dice.rerollPhaseAmount = 0;
                Dice.duelAlreadyAdded = false;
                dynamiteLifeTaken = false;
                turnTerminated = false;
                oldSaloonDiceNumber = 0;
                numberUserChoiceOldSaloonDice = 0;
                oldSaloonDiceApplication = 0;
                oldSaloonDiceChoice = 0;
                dynamiteLifeTaken = false;
                turnTerminated = false;
                Dice.rerollPhaseAmount = 0;
                //users turn
                if(playersTurn.name.equals(chosenCharacter)){
                    //System.out.println("playersTurn name: " + playersTurn.name + " usersTurn name: " + chosenCharacter);
                    System.out.println("press to roll: "+ "\n" + "1: Coward Dice " + "\n" + "2: LoudMouth Dice" + "\n" + "3: roll all regular dice");
                         do{
                                try{
                                        do{
                                            if(oldSaloonDiceChoice >= 1)
                                            System.out.println("not a valid dice please try again");
                                            userChoiceOldSaloonDice = scan.nextLine();
                                            numberUserChoiceOldSaloonDice = Integer.parseInt(userChoiceOldSaloonDice);
                                            validOldSaloonDice = true;
                                            oldSaloonDiceChoice++;
                                        }while(numberUserChoiceOldSaloonDice != 1 && numberUserChoiceOldSaloonDice != 2 && numberUserChoiceOldSaloonDice != 3);
                                    }catch(NumberFormatException v){
                                        validOldSaloonDice = false;
                                        System.out.println("not a valid dice please try again");
                                    }  
                        }while(validOldSaloonDice == false);
                         System.out.println("press enter to roll dice for your turn:" );
                         System.out.println("***********************************************");
                         promptUserRoll = scan.nextLine();
                       //rolls the dice for the user
                       numberOfRoll = 1;
                        do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            if(diceFaceString.equals("DYNAMITE"))
                            dynamiteCount++;
                            diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString + "(Duel Dice)");
                            timesRolled++;
                            numberOfRoll++;
                            duelDiceCount++;
                         }while(duelDiceCount != 2);
                         if(numberUserChoiceOldSaloonDice != 3){
                            if(numberUserChoiceOldSaloonDice == 1){
                                oldSaloonDiceNumber = 1;
                                playersRoll = rand.nextInt(6);
                                diceFaceString = CowardDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                        dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println( numberOfRoll + "." + diceFaceString  + "(Coward Dice)");
                                timesRolled++;
                                numberOfRoll++;
                             }
                            else if(numberUserChoiceOldSaloonDice == 2){
                                oldSaloonDiceNumber = 2;
                                playersRoll = rand.nextInt(6); 
                                diceFaceString = LoudMouthDiceFace.getLoudMouthDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println( numberOfRoll + "." + diceFaceString + "(LoudMouth Dice)");
                                timesRolled++;
                                numberOfRoll++;
                            }
                           do{
                                playersRoll = rand.nextInt(6);
                                diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println(numberOfRoll + "." + diceFaceString);
                                timesRolled++;
                                numberOfRoll++;
                            
                             }while(timesRolled  != 6);
                        }
                        else{
                              do{
                                    playersRoll = rand.nextInt(6);
                                    diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                    if(diceFaceString.equals("DYNAMITE"))
                                        dynamiteCount++;
                                    diceFacesRolled[timesRolled] = diceFaceString;
                                    System.out.println(numberOfRoll + "." + diceFaceString);
                                    timesRolled++;
                                    numberOfRoll++;
                            
                                }while(timesRolled  != 6);
                         }
                        //checks if there is already 3 dynamites rolled for rerolls
                        if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                            do{
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done.");
                               
                                 do{
                                     numberReroll = scan.nextLine();
                                     try{
                                         userChoiceOfReroll = -1;
                                         userChoiceOfReroll = Integer.parseInt(numberReroll);
                                         isNumber = true;
                                   }catch(NumberFormatException e){
                                     isNumber = false;
                                   }
                                 }while(!(isNumber = true));
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                                  Dice.diceFaceCountReroll[j] = 0;
                                  Dice.duelDiceCount[j] = 0;
                                  Dice.diceFaceCount[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                        System.out.println("***********************************************");
                        System.out.println("results:");
                        //allows the user to use the diceFaces they rolled
                        if(turnTerminated == false){
                            for(int i = 0;i < diceFacesRolled.length;i++){
                                Dice.numberOfCalculation++;
                                if(duelDiceCalculated != 2){
                                     diceFaceString = diceFacesRolled[i];
                                     Dice.duelDiceCalculations(diceFaceString);
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     duelDiceCalculated++; 
                                }else if(numberUserChoiceOldSaloonDice != 3 && oldSaloonDiceApplication == 0){
                                    if(numberUserChoiceOldSaloonDice == 1){
                                        diceFaceString = diceFacesRolled[i];
                                        Dice.cowardDiceFaceCalculations(diceFaceString);
                                        oldSaloonDiceApplication++;
                                    }
                                    else if(numberUserChoiceOldSaloonDice == 2){
                                        diceFaceString = diceFacesRolled[i];
                                        Dice.loudMouthDiceCalulations(diceFaceString);
                                        oldSaloonDiceApplication++;
                                    }
                                }
                                else{
                                     diceFaceString = diceFacesRolled[i];
                                     Dice.diceFaceCalculations(diceFaceString);
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     if(Dice.numberOfCalculation == 6 && Dice.duelCount != 0){
                                         duelActive = true;
                                          do{
                                                System.out.println("Duel initiated:");
                                                System.out.println("choose a person to do battle with");
                                                Dice.questionCount = 0;
                                                do{
                                                    if(Dice.questionCount > 0)
                                                    System.out.println(" player not found please try again");
                                                    Dice.userInput = "";
                                                    Dice.userInput = scan.nextLine();
                                                    Dice.userInput = Dice.userInput_toString(Dice.userInput);
                                                    //System.out.println(userInput);
                                                    Project3.effectedPlayer = CharacterLinkedList.searchCharacter(Dice.userInput,Project3.playersTurn);
                                                    //System.out.println(Project3.effectedPlayer.name);
                                                    //checks if the effected player's life is at its highest limit.
                                                    if(Project3.effectedPlayer != null ){
                                                        System.out.println("****************************************************");
                                                        System.out.println(Project3.effectedPlayer.player + " has been challenged to a duel" + "\n" + "press enter continue");
                                                    //let other player roll dice 
                                                    do{
                                                        System.out.println(Project3.effectedPlayer.player + " roll:");
                                                        playersRoll = rand.nextInt(6);
                                                        defenderRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                        System.out.println(defenderRoll);
                                                        if(defenderRoll.equals("DUEL")){
                                                            System.out.println(Project3.playersTurn.player + " rolled DUEL now the challengers turn");
                                                            System.out.println(Project3.playersTurn.player + " roll:");
                                                            playersRoll = rand.nextInt(6);
                                                            challengersRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                              System.out.println(challengersRoll);
                                                            if(challengersRoll.equals("DUEL")){
                                                             System.out.println(Project3.playersTurn.player + " rolled DUEL now the defenders turn");
                                                            }
                                                            else{
                                                                System.out.println(Project3.playersTurn.player + " has lost the duel");
                                                                DuelWoundToken.giveBattleWound(Project3.playersTurn);
                                                                duelOver = true;
                                                            }
                                                        }
                                                        else{
                                                            System.out.println(Project3.effectedPlayer.player + " has lost the duel");
                                                             DuelWoundToken.giveBattleWound(Project3.effectedPlayer);
                                                            duelOver = true;
                                                        }
                                                           
                                                        
                                                    }while(duelOver == false);
                                                    
                                                            //if the character rolls a duel then pass on to the player who challenged them and let them battle
                                                            //until somebody doesnt roll a duel give the loser a battle wound token
                                                    }
                                                    Dice.questionCount++;
                                                 }while(Project3.effectedPlayer == null);
                                             Dice.questionCount--;
                                             Dice.duelCount--;
                                         }while(Dice.duelCount != 0);
                                     }
                            }
                            if(turnTerminated == true)
                                break;
                            }   
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){      
                                  Dice.diceFaceCountReroll[i] = 0;
                                  Dice.duelDiceCount[i] = 0;
                                  Dice.diceFaceCount[i] = 0;
                        }
                }
                else{          
                                //A.I.'s Turn
                        System.out.println( "\n" + "press enter to see" + playersTurn.player + " results" );
                        System.out.println("***********************************************");
                        promptUserRoll = scan.nextLine();
                        do{
                                  numberUserChoiceOldSaloonDice = rand.nextInt(4);
                            }while( numberUserChoiceOldSaloonDice == 0);
                        //rolls the dice for the AI
                        numberOfRoll = 1;
                         do{
                            playersRoll = rand.nextInt(6);
                            diceFaceString = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                            if(diceFaceString.equals("DYNAMITE"))
                            dynamiteCount++;
                            diceFacesRolled[timesRolled] = diceFaceString;
                            System.out.println(numberOfRoll + "." + diceFaceString + "(Duel Dice)");
                            timesRolled++;
                            numberOfRoll++;
                            duelDiceCount++;
                         }while(duelDiceCount != 2);
                         if(numberUserChoiceOldSaloonDice != 3){
                            if(numberUserChoiceOldSaloonDice == 1){
                                oldSaloonDiceNumber = 1;
                                playersRoll = rand.nextInt(6);
                                diceFaceString = CowardDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                        dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println( numberOfRoll + "." + diceFaceString  + "(Coward Dice)");
                                timesRolled++;
                                numberOfRoll++;
                             }
                            else if(numberUserChoiceOldSaloonDice == 2){
                                oldSaloonDiceNumber = 2;
                                playersRoll = rand.nextInt(6); 
                                diceFaceString = LoudMouthDiceFace.getLoudMouthDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println( numberOfRoll + "." + diceFaceString + "(LoudMouth Dice)");
                                timesRolled++;
                                numberOfRoll++;
                            }
                           }
                           do{
                                playersRoll = rand.nextInt(6);
                                diceFaceString = DiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                if(diceFaceString.equals("DYNAMITE"))
                                    dynamiteCount++;
                                diceFacesRolled[timesRolled] = diceFaceString;
                                System.out.println(numberOfRoll + "." + diceFaceString);
                                timesRolled++;
                                numberOfRoll++;
                            
                             }while(timesRolled  != 6);
                        if(!(dynamiteCount >= 3)){  
                             //allows the option of rerolls 
                            System.out.println("***********************************************");
                           do{
                                 
                                 System.out.println("enter the number of dice that you would like to reroll, enter a 7 when done with this reroll phase.");
                                 do{
                                    userChoiceOfReroll = rand.nextInt(8);
                                 }while(userChoiceOfReroll == 0);
                                 System.out.println(userChoiceOfReroll);
                                 Dice.reroll(userChoiceOfReroll);
                                 CharacterList.deletePlayers(effectedPlayer);
                                 if(turnTerminated == true)
                                     break;
                             }while(Dice.rerollTerminated == false); 
                             System.out.println("***********************************************");
                             
                             //shows the final dice and resets the reroll counters back to 0.
                             for(int j = 0; j < diceFacesRolled.length;j++){
                           
                                  System.out.println(diceFacesRolled[j]);
                                  Dice.diceFaceCountReroll[j] = 0;
                             }
                        }
                        else{
                            System.out.println(" have rolled 3 DYNAMITES rerolls are not available");
                            System.out.println(playersTurn.player + " has lost a life, they now have " + playersTurn.lifes + " lifes");
                            dynamiteLifeTaken = true;
                        }
                         System.out.println("***********************************************");
                          //allows the AI to use the diceFaces they rolled
                        for(int i = 0;i < diceFacesRolled.length;i++){       
                             gameOver = winConditions.checkWinConditions();
                             if(gameOver == true){
                               break;
                             }
                              Dice.numberOfCalculation++;
                             if(duelDiceCalculated != 2){
                                     diceFaceString = diceFacesRolled[i];
                                     //checks for the battle wound token calculations
                                     DuelWoundToken.calculateBattleWound(diceFaceString);
                                     if(!(DuelWoundToken.battleWoundTokenActivated == true))
                                        Dice.duelDiceCalculations(diceFaceString);
                                     else {
                                         System.out.println(diceFaceString + " has been canceled due to a battle wound");
                                         DuelWoundToken.battleWoundTokenActivated = false;
                                     }
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     duelDiceCalculated++; 
                                }
                                else{
                                     diceFaceString = diceFacesRolled[i];
                                      //checks for the battle wound token calculations
                                     DuelWoundToken.calculateBattleWound(diceFaceString);
                                     if(!(DuelWoundToken.battleWoundTokenActivated == true))
                                       Dice.diceFaceCalculations(diceFaceString);
                                     else {
                                         System.out.println(diceFaceString + " has been canceled due to a battle wound");
                                         DuelWoundToken.battleWoundTokenActivated = false;
                                     }
                                     //removes player if needed after every calculation occurs
                                     CharacterList.deletePlayers(ArrowAttack);
                                     if(Dice.numberOfCalculation == 6 && Dice.duelCount != 0){
                                         duelActive = true;
                                          do{
                                                System.out.println("Duel initiated:");
                                                System.out.println("choose a person to do battle with");
                                                Dice.questionCount = 0;
                                                do{
                                                    //A.I searches for duel partner
                                                    Project3.effectedPlayer = CharacterLinkedList.searchRandom(1,1);
                                                    //System.out.println(Project3.effectedPlayer.name);
                                                    if(Project3.effectedPlayer != null ){
                                                        System.out.println("****************************************************");
                                                        System.out.println(Project3.effectedPlayer.player + " has been challenged to a duel" + "\n" + "press enter continue");
                                                    //let other player roll dice 
                                                    do{
                                                        System.out.println(Project3.effectedPlayer.player + " roll:");
                                                        playersRoll = rand.nextInt(6);
                                                        defenderRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                        System.out.println(defenderRoll);
                                                        if(defenderRoll.equals("DUEL")){
                                                            System.out.println(Project3.playersTurn.player + " rolled DUEL now the challengers turn");
                                                            System.out.println(Project3.playersTurn.player + " roll:");
                                                            playersRoll = rand.nextInt(6);
                                                            challengersRoll = DuelDiceFace.getDiceFace(playersRoll).getdiceFace_toString();
                                                            if(challengersRoll.equals("DUEL")){
                                                             System.out.println(Project3.playersTurn.player + " rolled DUEL now the defenders turn");
                                                            }
                                                            else{
                                                                System.out.println(Project3.playersTurn.player + " has lost the duel");
                                                                DuelWoundToken.giveBattleWound(Project3.playersTurn);
                                                                duelOver = true;
                                                            }
                                                        }
                                                        else{
                                                            System.out.println(Project3.effectedPlayer.player + " has lost the duel");
                                                             DuelWoundToken.giveBattleWound(Project3.effectedPlayer);
                                                            duelOver = true;
                                                        }
                                                           
                                                        
                                                    }while(duelOver == false);
                                                    
                                                            //if the character rolls a duel then pass on to the player who challenged them and let them battle
                                                            //until somebody doesnt roll a duel give the loser a battle wound token
                                                    }
                                                 }while(Project3.effectedPlayer == null);
                                             Dice.duelCount--;
                                         }while(Dice.duelCount != 0);
                                     }
                            }
                            if(turnTerminated ==  true)
                               break;
                        }
                        //resets dice count
                        for(int i = 0;i < Dice.diceFaceCount.length;i++){       
                            
                            Dice.diceFaceCount[i] = 0;
                            
                        }
                }
             gameOver = winConditions.checkWinConditions();
             if(gameOver == true)
                 break;
              playersTurn = playersTurn.next; 
              if(playersTurn == CharacterList.start){ 
                  roundOver = true;
              }
           }
           if(gameOver == true)
               break;
           roundCount++;
           roundOver = false;
           System.out.println("_____________________________________");
           System.out.println("\n" + " end of round " + roundCount);
           DuelWoundToken.removeBattleWoundTokens(ArrowAttack);
           System.out.println("\n" + "Remaining players");
           CharacterList.show();
           DeadList.show();
           if(zombieOutbreakCount == 0) 
                mainStartZombieOutbreak = DeadList.checkZombieOutbreak();
           if(DeadList.zombieOutbreakStart == true && zombieOutbreakCount == 0){
               if(mainStartZombieOutbreak = true){
                   DeadList.bringZombiesInGame();
               }
               zombieOutbreakCount++;
               CharacterList.show();
           }
           
       }
           System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
           System.out.println("GAME OVER"); 
    }
 }

}
