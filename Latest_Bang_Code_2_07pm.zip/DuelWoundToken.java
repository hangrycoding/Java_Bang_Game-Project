/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;
import java.util.Random;
import static project3.CharacterLinkedList.currentNode;

/**
 *
 * @author Dylan Lowman
 */
public class DuelWoundToken {
    static boolean battleWoundTokenActivated;
    static int randomBattleToken;
    static Random rand = new Random();
    public static void giveBattleWound(Node loser){
        
        randomBattleToken = rand.nextInt(4);
        if(!(loser.role.equals("ZOMBIE"))){
                                                                       
            if(randomBattleToken == 0){
                System.out.println(loser.player + " has been given a BEER cancelation battle wound token");
                loser.duelWoundLink.add("BEER");
            }else if(randomBattleToken == 1){
                System.out.println(loser.player + " has been given a BULLSEYE1 cancelation battle wound token");
                loser.duelWoundLink.add("BULLSEYE1");
            }else if(randomBattleToken == 2){
                System.out.println(loser.player + " has been given a BULLSEYE2 cancelation battle wound token");
                loser.duelWoundLink.add("BULLSEYE2");
            }else if(randomBattleToken == 3){
                System.out.println(loser.player + " has been given a DYNAMITE battle wound token");
                loser.duelWoundLink.add("DYNAMITE");
            }                 
        }
        else{ 
             System.out.println("cant gain a battle wound since " + loser.player +  " is a zombie");
        }
    }
    public static void calculateBattleWound(String diceFace){
        if(Project3.playersTurn.duelWoundLink.contains(diceFace))
        {
            System.out.println("Battle Wound Token Activated");
            battleWoundTokenActivated = true;
            Project3.playersTurn.duelWoundLink.remove(diceFace);
        }
        
    }
    public static void removeBattleWoundTokens(Node ArrowAttack){
         currentNode = CharacterLinkedList.start;
          
       do{
           currentNode.duelWoundLink.clear();
           currentNode = currentNode.next; 
           
       }while(currentNode != CharacterLinkedList.start);
       System.out.println("everybody's duel wound tokens have been removed");
    }
}
